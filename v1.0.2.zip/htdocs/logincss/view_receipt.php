<?php
session_start(); // Start session

// --------------------
// Session-based access control
// --------------------
if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    // Not logged in, redirect to login page
    header("Location: ../login.php");
    exit();
}

// Optionally, get username and role
$username = htmlspecialchars($_SESSION['username']);
$role = $_SESSION['role'];

// Then include your config file
require_once 'config.php'; // DB connection

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$errors = [];
$student = null;
$receipts = [];
$academicYears = [];
$totalAmount = 0; // Initialize total amount

// ---------------------------
// Fetch Academic Years
// ---------------------------
$year_sql = "SELECT Academic_Year FROM ATGET_Academic_Year ORDER BY Academic_Year ASC";
$year_result = $conn->query($year_sql);
if ($year_result && $year_result->num_rows > 0) {
    while ($row = $year_result->fetch_assoc()) {
        $academicYears[] = $row['Academic_Year'];
    }
}

// ---------------------------
// Handle Search Request
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admissionNo = trim($_POST['admissionNo'] ?? '');
    $academicYear = trim($_POST['academicYear'] ?? '');

    if (empty($admissionNo) || empty($academicYear)) {
        $errors[] = "Please enter Admission Number and select Academic Year.";
    } else {
        // Fetch student details
        $stmt1 = $conn->prepare("SELECT Admission_No, Student_Name, Parent_Name, Contact_No, School_Name 
                                 FROM ATGET_Students_Details 
                                 WHERE Admission_No = ?");
        $stmt1->bind_param("s", $admissionNo);
        $stmt1->execute();
        $result1 = $stmt1->get_result();
        if ($result1 && $result1->num_rows > 0) {
            $student = $result1->fetch_assoc();
        } else {
            $errors[] = "No student found for Admission Number: $admissionNo";
        }

        // Fetch receipt details
        $stmt2 = $conn->prepare("SELECT Receipt_No, Receipt_Date, Receipt_Amount, Prepared_By 
                                 FROM ATGET_Receipt_Details 
                                 WHERE Admission_No = ? AND Academic_Year = ?
                                 ORDER BY Receipt_Date ASC");
        $stmt2->bind_param("ss", $admissionNo, $academicYear);
        $stmt2->execute();
        $result2 = $stmt2->get_result();
        if ($result2 && $result2->num_rows > 0) {
            while ($row = $result2->fetch_assoc()) {
                $receipts[] = $row;
                $totalAmount += $row['Receipt_Amount']; // Sum total amount
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Receipts</title>
<style>
/* ----------------------------
   Layout
---------------------------- */
body {
    font-family: 'Segoe UI', Arial, sans-serif;
    background: #f3f3f3;
    margin: 0;
    padding: 15px;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.container {
    background: #fff;
    border-radius: 12px;
    padding: 20px;
    box-shadow: 0 0 20px rgba(0,0,0,0.15);
    width: 100%;
    max-width: 550px;
}

/* ----------------------------
   Navbar (Inside Container)
---------------------------- */
.navbar {
    display: flex;
    justify-content: space-between;
    background-color: #333;
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 20px;
}

.navbar a {
    color: white;
    text-align: center;
    padding: 14px;
    text-decoration: none;
    flex: 1;
    font-weight: 500;
}

.navbar a:hover {
    background-color: #04AA6D;
}

/* ----------------------------
   Typography
---------------------------- */
h2 {
    text-align: center;
    color: #333;
    margin-bottom: 20px;
}

/* ----------------------------
   Form Styling
---------------------------- */
form {
    display: flex;
    flex-wrap: wrap;
    align-items: flex-end;
    gap: 10px;
    margin-bottom: 20px;
}

form div {
    flex: 1;
    min-width: 120px;
}

form label {
    font-weight: bold;
    font-size: 14px;
    display: block;
    margin-bottom: 5px;
}

form input, form select {
    padding: 8px;
    border-radius: 6px;
    border: 1px solid #ccc;
    font-size: 15px;
    width: 100%;
    box-sizing: border-box;
}

form button {
    background-color: #04AA6D;
    color: #fff;
    border: none;
    border-radius: 6px;
    padding: 10px 16px;
    cursor: pointer;
    font-size: 15px;
    flex: 0 0 auto;
    white-space: nowrap;
    align-self: flex-end;
}

form button:hover {
    background-color: #028a5e;
}

/* ----------------------------
   Error Message
---------------------------- */
.error {
    background-color: #fde4e4;
    color: #c00;
    padding: 10px;
    border-radius: 6px;
    margin-bottom: 15px;
    font-size: 15px;
}

/* ----------------------------
   Tables
---------------------------- */
.table-section {
    margin-top: 20px;
}

table {
    border-collapse: collapse;
    width: 100%;
    table-layout: auto; /* Allow table to shrink naturally */
}

table th, table td {
    border: 1px solid #ccc;
    padding: 8px; /* Slightly smaller for mobile */
    text-align: left;
    word-break: break-word;
}

table th {
    background-color: #04AA6D;
    color: #fff;
}

.no-data {
    text-align: center;
    padding: 20px;
    color: #666;
    font-style: italic;
}

/* ----------------------------
   Responsive Design
---------------------------- */
@media (max-width: 768px) {
    form {
        flex-direction: column;
        align-items: stretch;
    }

    form div, form button {
        width: 100%;
    }

    table th, table td {
        font-size: 13px;
        padding: 6px;
    }
}
</style>
</head>
<body>
<div class="container">
    <!-- Navbar -->
    <div class="navbar">
        <a href="atgethome.php" class="active">Home</a>
        <a href="logout.php">Logout</a>
    </div>

    <h2>View Receipts</h2>

    <!-- Error Messages -->
    <?php if (!empty($errors)): ?>
    <div class="error">
        <?php foreach ($errors as $error): ?>
        <p><?= htmlspecialchars($error) ?></p>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- Search Form -->
    <form method="POST" action="">
        <div>
            <label for="admissionNo">Admission Number:</label>
            <input type="number" id="admissionNo" name="admissionNo"
                placeholder="Enter Admission No"
                value="<?= htmlspecialchars($_POST['admissionNo'] ?? '') ?>" required>
        </div>

        <div>
            <label for="academicYear">Academic Year:</label>
            <select id="academicYear" name="academicYear" required>
                <option value="" disabled selected>-- Select Year --</option>
                <?php foreach ($academicYears as $year): ?>
                <option value="<?= htmlspecialchars($year) ?>"
                    <?= (($_POST['academicYear'] ?? '') === $year) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($year) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit">Search</button>
    </form>

    <!-- Student Details -->
    <?php if ($student): ?>
    <div class="table-section">
        <h3>Student Details</h3>
        <table>
            <tr><th>Admission No</th><td><?= htmlspecialchars($student['Admission_No']) ?></td></tr>
            <tr><th>Student Name</th><td><?= htmlspecialchars($student['Student_Name']) ?></td></tr>
            <tr><th>Parent Name</th><td><?= htmlspecialchars($student['Parent_Name']) ?></td></tr>
            <tr><th>Contact No</th><td><?= htmlspecialchars($student['Contact_No']) ?></td></tr>
            <tr><th>School Name</th><td><?= htmlspecialchars($student['School_Name']) ?></td></tr>
            <tr><th>Total Amount (₹)</th><td><?= number_format($totalAmount, 2) ?></td></tr>
        </table>
    </div>
    <?php endif; ?>

    <!-- Receipt Details -->
    <?php if (!empty($receipts)): ?>
    <div class="table-section">
        <h3>Receipt Details</h3>
        <table>
            <thead>
                <tr>
                    <th>Receipt No</th>
                    <th>Receipt Date</th>
                    <th>Amount (₹)</th>
                    <th>Prepared By</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($receipts as $receipt): ?>
                <tr>
                    <td><?= htmlspecialchars($receipt['Receipt_No']) ?></td>
                    <td><?= date('d-m-Y', strtotime($receipt['Receipt_Date'])) ?></td>
                    <td><?= number_format($receipt['Receipt_Amount'], 2) ?></td>
                    <td><?= htmlspecialchars($receipt['Prepared_By']) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php elseif ($student && empty($receipts)): ?>
    <div class="no-data">No receipts found for this Admission No and Academic Year.</div>
    <?php endif; ?>
</div>
</body>
</html>

<?php
require_once 'logincss/config.php';
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$errors = [];
$student = null;
$resultData = null;
$success = '';
$classes = [];
$semesters = [];

// Fetch Classes
$class_sql = "SELECT Standard_List FROM ATGET_School_Standards ORDER BY Standard_List ASC";
$class_result = $conn->query($class_sql);
if ($class_result && $class_result->num_rows > 0) {
    while ($row = $class_result->fetch_assoc()) {
        $classes[] = $row['Standard_List'];
    }
}

// Fetch Semesters
$sem_sql = "SELECT Semester_Name FROM ATGET_School_Semisters ORDER BY Semester_Name ASC";
$sem_result = $conn->query($sem_sql);
if ($sem_result && $sem_result->num_rows > 0) {
    while ($row = $sem_result->fetch_assoc()) {
        $semesters[] = $row['Semester_Name'];
    }
}

// Handle Search
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['searchResult'])) {
    $admissionNo = trim($_POST['admissionNo']);
    $class = trim($_POST['class']);
    $semester = trim($_POST['semester']);

    if (!$admissionNo || !$class || !$semester) {
        $errors[] = "All fields are required.";
    } else {
        if($admissionNo < 0) {
            $errors[] = "Admission number cannot be negative.";
        } else {
            // Fetch Student Details
            $stmt1 = $conn->prepare("SELECT Student_Name, Parent_Name, School_Name FROM ATGET_Students_Details WHERE Admission_No = ?");
            $stmt1->bind_param("s", $admissionNo);
            $stmt1->execute();
            $res1 = $stmt1->get_result();
            if ($res1 && $res1->num_rows > 0) {
                $student = $res1->fetch_assoc();

                // Fetch Result Details
                $stmt2 = $conn->prepare("SELECT Marks_Obtained_For_Attendance, Marks_Obtained_In_Assesment, Marks_Obtained_In_Theory_Exam, Marks_Obtained_In_Lab_Exam, Total_Marks_Obtained, Marks_In_Grade 
                                        FROM ATGET_Schools_Result_Table 
                                        WHERE Admission_No = ? AND Current_ClassOrStandard = ? AND Semister = ?");
                $stmt2->bind_param("sss", $admissionNo, $class, $semester);
                $stmt2->execute();
                $res2 = $stmt2->get_result();
                if ($res2 && $res2->num_rows > 0) {
                    $resultData = $res2->fetch_assoc();
                    $success = "Result found!";
                } else {
                    $errors[] = "No result found for this student in selected class and semester.";
                }
            } else {
                $errors[] = "Student not found.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View School Result</title>
<style>
body { font-family: Arial, sans-serif; background: #f3f3f3; margin:0; display:flex; justify-content:center; padding:20px; }
.main-card { background:#fff; border-radius:15px; padding:25px; box-shadow:0 0 20px rgba(0,0,0,0.15); width:100%; max-width:600px; }

.header {
    text-align:center;
    font-size:26px;
    font-weight:bold;
    color:white;
    padding:15px 10px;
    border-radius:10px;
    background: linear-gradient(90deg, #4CAF50, #2196F3);
    box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    margin-bottom:20px;
    letter-spacing:1px;
}

h2,h3 { margin:0; color:#333; }
.error, .success { padding:10px; border-radius:5px; margin-bottom:15px; text-align:center; }
.error { background-color:#fdd; color:red; }
.success { background-color:#dff0d8; color:#3c763d; }

/* Responsive 4rows x 2 columns layout */
.search-grid {
    display: grid;
    grid-template-columns: 40% 60%;
    grid-template-rows: auto auto auto auto;
    gap: 8px 10px;
    margin-bottom:20px;
}

.search-grid label { text-align:left; font-weight:bold; }
.search-grid input, .search-grid select{
    width:95%;
    padding:6px;
    border:1px solid #ccc;
    border-radius:5px;
    font-size:16px;
}

/* Buttons in last row */
.search-grid .search-button, .search-grid .go-back-btn {
    width:100%;
    padding:8px;
    border:none;
    border-radius:5px;
    cursor:pointer;
    font-size:16px;
}

.search-grid .search-button { background-color:#4CAF50; color:white; }
.search-grid .search-button:hover { background-color:#45a049; }
.search-grid .go-back-btn { background:#2196F3; color:white; }
.search-grid .go-back-btn:hover { background:#0b7dda; }

.result-container {
    display:flex;
    justify-content:space-between;
    gap:15px;
    margin-top:20px;
}

.result-card {
    background:#eef6ff;
    border-left:5px solid #4CAF50;
    padding:15px;
    border-radius:8px;
    flex:1 1 48%; /* 50% each */
}

.result-card p { display:flex; justify-content:space-between; margin:5px 0; }
.result-card p span:first-child { font-weight:bold; }

.animation-container {
    text-align:center;
    margin-top:20px;
    font-size:18px;
    font-weight:bold;
    color:white;
    background:green;
    padding:10px;
    border-radius:8px;
    animation: blink 5s infinite;
}

@keyframes blink {
    0%,50%,100% { background:green; color:white; transform: scale(1); }
    25%,75% { background:white; color:green; transform: scale(1.05); }
}

@media (max-width:700px) {
    .result-container { flex-direction:column; }
    .result-card { flex:1 1 100%; margin-bottom:15px; }
}
</style>
</head>
<body>
<div class="main-card">

<div class="header">Assure Tech Global Education Trust(R)</div>

<h2><center>View Result</center></h2><br>

<?php if (!empty($errors)): ?>
<div class="error">
    <?php foreach($errors as $e): ?>
        <p><?= htmlspecialchars($e) ?></p>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if($success): ?>
<div class="success"><?= htmlspecialchars($success) ?> 🎉</div>
<?php endif; ?>

<form method="POST" action="">
    <div class="search-grid">
        <!-- Row 1: Admission No label -->
        <label for="admissionNo">Admission No:</label>
        <input type="number" min="0" name="admissionNo" id="admissionNo" required value="<?= htmlspecialchars($_POST['admissionNo'] ?? '') ?>">

        <!-- Row 2: Class label & select -->
        <label for="class">Class:</label>
        <select name="class" id="class" required>
            <option value="" disabled>- Select Class -</option>
            <?php foreach($classes as $c): ?>
                <option value="<?= htmlspecialchars($c) ?>" <?= (isset($_POST['class']) && $_POST['class']==$c)?'selected':'' ?>><?= htmlspecialchars($c) ?></option>
            <?php endforeach; ?>
        </select>

        <!-- Row 3: Semester label & select -->
        <label for="semester">Semester:</label>
        <select name="semester" id="semester" required>
            <option value="" disabled>- Select Semester -</option>
            <?php foreach($semesters as $s): ?>
                <option value="<?= htmlspecialchars($s) ?>" <?= (isset($_POST['semester']) && $_POST['semester']==$s)?'selected':'' ?>><?= htmlspecialchars($s) ?></option>
            <?php endforeach; ?>
        </select>

        <!-- Row 4: Go Back button & Search button -->
        <button type="button" class="go-back-btn" onclick="window.location.href='index.html'">Go Back</button>
        <button type="submit" name="searchResult" class="search-button">Search</button>
    </div>
</form>

<?php if($student && $resultData): ?>
<div class="result-container">
    <div class="result-card">
        <h3>Student Details</h3>
        <p><span>Name:</span> <span><?= htmlspecialchars($student['Student_Name']) ?></span></p>
        <p><span>Parent Name:</span> <span><?= htmlspecialchars($student['Parent_Name']) ?></span></p>
        <p><span>School:</span> <span><?= htmlspecialchars($student['School_Name']) ?></span></p>
    </div>
    <div class="result-card">
        <h3>Result Details</h3>
        <p><span>Attendance Marks:</span> <span><?= htmlspecialchars($resultData['Marks_Obtained_For_Attendance']) ?></span></p>
        <p><span>Assessment Marks:</span> <span><?= htmlspecialchars($resultData['Marks_Obtained_In_Assesment']) ?></span></p>
        <p><span>Theory Exam Marks:</span> <span><?= htmlspecialchars($resultData['Marks_Obtained_In_Theory_Exam']) ?></span></p>
        <p><span>Lab Exam Marks:</span> <span><?= htmlspecialchars($resultData['Marks_Obtained_In_Lab_Exam']) ?></span></p>
    </div>
</div>

<div class="animation-container">
    Total Marks: <?= htmlspecialchars($resultData['Total_Marks_Obtained']) ?> | Grade: <?= htmlspecialchars($resultData['Marks_In_Grade']) ?> 🎉 Congratulations!
</div>
<?php endif; ?>

</div>
</body>
</html>

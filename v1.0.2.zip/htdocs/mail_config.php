<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

/**
 * Create and return configured PHPMailer instance
 */
function getMailer(): PHPMailer {
    $mail = new PHPMailer(true);

    // SMTP Settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'assuretechget@gmail.com';   // your email
    $mail->Password   = 'parpszrpjpwlqipq';         // Gmail App Password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Sender Info
    $mail->setFrom('assuretechget@gmail.com', 'ATGET Website');

    return $mail;
}
?>

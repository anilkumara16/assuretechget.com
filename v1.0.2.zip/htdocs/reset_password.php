<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('logincss/config.php'); // DB config
mysqli_set_charset($conn, "utf8mb4");

$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $dob = trim($_POST['dob'] ?? '');
    $newPassword = trim($_POST['new_password'] ?? '');

    if ($username === '' || $dob === '' || $newPassword === '') {
        $message = "All fields are required (Username, Date of Birth, and New Password).";
    } else {
        // Check if username + DOB match
        $stmt = $conn->prepare("SELECT * FROM ATGET_Login_Creds WHERE username = ? AND Date_of_Birth = ?");
        $stmt->bind_param("ss", $username, $dob);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Hash new password
            $hashed = password_hash($newPassword, PASSWORD_DEFAULT);

            // Update password securely
            $update = $conn->prepare("UPDATE ATGET_Login_Creds SET password = ? WHERE username = ?");
            $update->bind_param("ss", $hashed, $username);

            if ($update->execute()) {
                $message = "Password successfully updated for user: $username";
            } else {
                $message = "Error: Failed to update password. Please try again.";
            }

            $update->close();
        } else {
            $message = "Invalid username or Date of Birth. Please try again.";
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Reset Password - ATGET</title>
    <link rel="stylesheet" href="logincss/style.css">
    <link rel="icon" href="img/ATG Logo.png" type="image/png">
</head>

<body>
    <div class="main">
        <h1>Assure Tech Global Education Trust</h1>
        <h3>Reset User Password</h3>

        <?php if ($message): ?>
            <script>
                alert('<?= addslashes($message) ?>');
                window.location.href = 'login.php';
            </script>
        <?php endif; ?>

        <form action="" method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder="Enter Username" required>

            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob" required>

            <label for="new_password">New Password:</label>
            <input type="password" id="new_password" name="new_password" placeholder="Enter New Password" required>

            <div class="wrap">
                <button type="submit">Reset Password</button>
            </div>
        </form>

        <p><a href="login.php">Back to Login Page</a></p>
    </div>
</body>
</html>

<?php
    error_reporting(E_ALL);
	ini_set('display_errors', 1);

// Include DB config
require_once('config.php'); // Make sure the path is correct

// Get form inputs
$user = $_POST['username'];
$pass = $_POST['password'];

// Prepare and execute SQL query
$sql = $conn->prepare("SELECT * FROM ATGET_Login_Creds WHERE username = ? AND password = ?");
$sql->bind_param("ss", $user, $pass);
$sql->execute();
$result = $sql->get_result();

if ($result->num_rows > 0) {
    //echo "Login successful!";
    header("Location: atgethomepage.html?message=".urlencode($user));
    exit();
} else {
    //echo "Invalid username or password.";
  
    // Display an alert message and redirect
    echo "<script>
        alert('Invalid username or password. You are being redirected to login page..!');
        window.location.href = '../login.html';
    </script>";
    exit;
}

$sql->close();
$conn->close();
?>

<?php
require_once 'config.php';
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$errors = [];
$success = '';
$student = null;
$semesters = [];

// ---------------------------
// Fetch Semesters
// ---------------------------
$sem_sql = "SELECT Semister_Name FROM ATGET_School_Semisters ORDER BY Semister_Name ASC";
$sem_result = $conn->query($sem_sql);
if ($sem_result && $sem_result->num_rows > 0) {
    while ($row = $sem_result->fetch_assoc()) {
        $semesters[] = $row['Semister_Name'];
    }
}

// ---------------------------
// Handle POST
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Search student
    if (isset($_POST['searchAdmissionNo'])) {
        $admissionNo = trim($_POST['searchAdmissionNo']);
        if (empty($admissionNo)) {
            $errors[] = "Please enter Admission Number.";
        } else {
            $stmt = $conn->prepare("SELECT * FROM ATGET_Students_Details WHERE Admission_No = ?");
            $stmt->bind_param("s", $admissionNo);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $student = $result->fetch_assoc();
            } else {
                $errors[] = "Student with Admission No '$admissionNo' not found.";
            }
        }
    }

    // Insert result
    elseif (isset($_POST['submitResult'])) {
        $admissionNo  = trim($_POST['admissionNo']);
        $class        = trim($_POST['currentClass']);
        $semister     = trim($_POST['semister']);
        $attMarks     = floatval($_POST['attendanceMarks']);
        $assessMarks  = floatval($_POST['assessmentMarks']);
        $theoryMarks  = floatval($_POST['theoryMarks']);
        $labMarks     = floatval($_POST['labMarks']);
        $totalMarks   = $attMarks + $assessMarks + $theoryMarks + $labMarks;
        $grade        = trim($_POST['grade']);

        if (!$admissionNo || !$class || !$semister || !$grade) {
            $errors[] = "All fields are required.";
        }

        if (empty($errors)) {
            $stmt = $conn->prepare("INSERT INTO ATGET_Schools_Result_Table 
                (Admission_No, Current_ClassOrStandard, Semister, Marks_Obtained_For_Attendance, Marks_Obtained_In_Assesment, Marks_Obtained_In_Theory_Exam, Marks_Obtained_In_Lab_Exam, Total_Marks_Obtained, Marks_In_Grade)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt === false) {
                $errors[] = "Prepare failed: " . $conn->error;
            } else {
                $stmt->bind_param("sssddddds", $admissionNo, $class, $semister, $attMarks, $assessMarks, $theoryMarks, $labMarks, $totalMarks, $grade);
                if ($stmt->execute()) {
                    $success = "Result updated successfully!";
                } else {
                    $errors[] = "Database error: " . $stmt->error;
                }
            }
        }

        // Fetch student again
        if ($admissionNo) {
            $stmt2 = $conn->prepare("SELECT * FROM ATGET_Students_Details WHERE Admission_No = ?");
            $stmt2->bind_param("s", $admissionNo);
            $stmt2->execute();
            $result2 = $stmt2->get_result();
            if ($result2 && $result2->num_rows > 0) {
                $student = $result2->fetch_assoc();
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Update Student Result</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f3f3f3;
    margin: 0;
    display: flex;
    justify-content: center;
    padding: 20px;
}
.main-card {
    background: #fff;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 0 20px rgba(0,0,0,0.15);
    width: 100%;
    max-width: 650px;
}
.navbar {
    display: flex;
    justify-content: space-between;
    background-color: #333;
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 20px;
}
.navbar a {
    color: white;
    text-align: center;
    padding: 14px;
    text-decoration: none;
    flex: 1;
}
.navbar a:hover { background-color: #111; }
.navbar a.active { background-color: #04AA6D; }

h2, h3 { margin: 0; color: #333; }

.error, .success {
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 15px;
}
.error { background-color: #fdd; color: red; }
.success { background-color: #dff0d8; color: #3c763d; }

form .form-row {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 15px;
    align-items: center;
}
form .form-row label {
    flex: 1 0 45%;
    padding-right: 10px;
    font-weight: bold;
}
form .form-row input,
form .form-row select {
    flex: 1 1 50%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
}
button {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
}
button:hover { background-color: #45a049; }

/* Inline search bar */
.search-bar {
    display: flex;
    gap: 10px;
    flex-wrap: nowrap;
    margin-bottom: 20px;
}
.search-bar input {
    flex: 1;
    padding: 8px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 5px;
}
.search-bar button {
    flex-shrink: 0;
}

/* Responsive tweaks */
@media (max-width: 600px) {
    form .form-row label {
        flex: 1 0 100%;
        margin-bottom: 5px;
    }
    form .form-row input,
    form .form-row select {
        flex: 1 0 100%;
    }
    .search-bar {
        flex-direction: column;
    }
    .search-bar button {
        width: 100%;
    }
}
</style>
</head>
<body>
<div class="main-card">

<!-- Navbar -->
<div class="navbar">
    <a href="atgethomepage.html" class="active">Home</a>
    <a href="../login.html">Logout</a>
</div>

<h2>Update Student Result</h2><br>

<!-- Messages -->
<?php if (!empty($errors)): ?>
<div class="error">
    <?php foreach ($errors as $error): ?>
        <p><?= htmlspecialchars($error) ?></p>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($success): ?>
<div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<!-- Search Form -->
<form method="POST" action="">
    <div class="search-bar">
        <input type="number" name="searchAdmissionNo" placeholder="Enter Admission No" required />
        <button type="submit">Search</button>
    </div>
</form>

<?php if ($student): ?>
<hr>
<h3>Student Details</h3>
<p><strong>Name:</strong> <?= htmlspecialchars($student['Student_Name']) ?></p>
<p><strong>Parent Name:</strong> <?= htmlspecialchars($student['Parent_Name']) ?></p>
<p><strong>School Name:</strong> <?= htmlspecialchars($student['School_Name']) ?></p>

<form method="POST" action="">
    <input type="hidden" name="admissionNo" value="<?= htmlspecialchars($student['Admission_No']) ?>" />

    <div class="form-row">
        <label for="currentClass">Current Class / Standard:</label>
        <input type="text" id="currentClass" name="currentClass" required>
    </div>

    <div class="form-row">
        <label for="semister">Semister:</label>
        <select id="semister" name="semister" required>
            <option value="" disabled selected>-- Select Semister --</option>
            <?php foreach ($semesters as $sem): ?>
                <option value="<?= htmlspecialchars($sem) ?>"><?= htmlspecialchars($sem) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-row">
        <label>Marks for Attendance:</label>
        <input type="number" id="attendanceMarks" name="attendanceMarks" step="0.01" required>
    </div>

    <div class="form-row">
        <label>Marks in Assessment:</label>
        <input type="number" id="assessmentMarks" name="assessmentMarks" step="0.01" required>
    </div>

    <div class="form-row">
        <label>Marks in Theory Exam:</label>
        <input type="number" id="theoryMarks" name="theoryMarks" step="0.01" required>
    </div>

    <div class="form-row">
        <label>Marks in Lab Exam:</label>
        <input type="number" id="labMarks" name="labMarks" step="0.01" required>
    </div>

    <div class="form-row">
        <label>Total Marks Obtained:</label>
        <input type="number" id="totalMarks" name="totalMarks" step="0.01" readonly>
    </div>

    <div class="form-row">
        <label>Grade:</label>
        <input type="text" id="grade" name="grade" required>
    </div>

    <button type="submit" name="submitResult">Submit Result</button>
</form>

<script>
function calculateTotal() {
    let a = parseFloat(document.getElementById('attendanceMarks').value) || 0;
    let b = parseFloat(document.getElementById('assessmentMarks').value) || 0;
    let c = parseFloat(document.getElementById('theoryMarks').value) || 0;
    let d = parseFloat(document.getElementById('labMarks').value) || 0;
    document.getElementById('totalMarks').value = (a + b + c + d).toFixed(2);
}
document.querySelectorAll('#attendanceMarks, #assessmentMarks, #theoryMarks, #labMarks')
    .forEach(input => input.addEventListener('input', calculateTotal));
</script>
<?php endif; ?>
</div>
</body>
</html>

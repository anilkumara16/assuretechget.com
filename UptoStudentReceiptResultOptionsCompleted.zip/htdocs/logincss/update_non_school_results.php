<?php
require_once 'config.php';
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$errors = [];
$success = '';
$student = null;
$courses = [];
$durations = [];
$grades = [];
$formData = []; // to retain user input on error

// ---------------------------
// Fetch Courses
$course_sql = "SELECT Course_Names FROM ATGET_Course_Names ORDER BY Course_Names ASC";
$course_result = $conn->query($course_sql);
if ($course_result && $course_result->num_rows > 0) {
    while ($row = $course_result->fetch_assoc()) {
        $courses[] = $row['Course_Names'];
    }
}

// Fetch Course Durations
$duration_sql = "SELECT Duration_In_Months FROM ATGET_Course_Duration ORDER BY Duration_In_Months ASC";
$duration_result = $conn->query($duration_sql);
if ($duration_result && $duration_result->num_rows > 0) {
    while ($row = $duration_result->fetch_assoc()) {
        $durations[] = $row['Duration_In_Months'];
    }
}

// Fetch Grades
$grade_sql = "SELECT Grading_List FROM ATGET_Grading_List ORDER BY Grading_List ASC";
$grade_result = $conn->query($grade_sql);
if ($grade_result && $grade_result->num_rows > 0) {
    while ($row = $grade_result->fetch_assoc()) {
        $grades[] = $row['Grading_List'];
    }
}

// ---------------------------
// Handle POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Search student
    if (isset($_POST['searchAdmissionNo'])) {
        $admissionNo = trim($_POST['searchAdmissionNo']);
        if (empty($admissionNo)) {
            $errors[] = "Please enter Admission Number.";
        } else {
            $stmt = $conn->prepare("SELECT * FROM ATGET_Students_Details WHERE Admission_No = ?");
            $stmt->bind_param("s", $admissionNo);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $student = $result->fetch_assoc();
                $formData = [
                    'courseName' => '',
                    'courseDuration' => '',
                    'courseStart' => '',
                    'courseEnd' => '',
                    'totalMarks' => '',
                    'grade' => ''
                ];
            } else {
                $errors[] = "Student with Admission No '$admissionNo' not found.";
            }
        }
    }

    // Insert Non-School Result
    elseif (isset($_POST['submitResult'])) {
        $admissionNo    = trim($_POST['admissionNo']);
        $studentName    = trim($_POST['studentName']);
        $parentName     = trim($_POST['parentName']);
        $courseName     = trim($_POST['courseName']);
        $courseDuration = intval($_POST['courseDuration']);
        $courseStart    = trim($_POST['courseStart']);
        $courseEnd      = trim($_POST['courseEnd']);
        $totalMarks     = floatval($_POST['totalMarks']);
        $grade          = trim($_POST['grade']);

        // Keep values for redisplay
        $formData = compact('courseName', 'courseDuration', 'courseStart', 'courseEnd', 'totalMarks', 'grade');

        if (!$admissionNo || !$studentName || !$parentName || !$courseName || !$courseDuration || !$courseStart || !$courseEnd || !$totalMarks || !$grade) {
            $errors[] = "All fields are required.";
        }

        if ($totalMarks <= 0) {
            $errors[] = "Total Marks Obtained must be greater than 0.";
        }

        // Validate start & end dates
        if ($courseStart && $courseEnd) {
            $startDate = DateTime::createFromFormat('Y-m', $courseStart);
            $endDate   = DateTime::createFromFormat('Y-m', $courseEnd);

            if (!$startDate || !$endDate) {
                $errors[] = "Invalid start or end date format.";
            } else {
                if ($startDate == $endDate) {
                    $errors[] = "Course start and end dates cannot be the same.";
                } else {
                    $diffMonths = ($endDate->format('Y') - $startDate->format('Y')) * 12 + ($endDate->format('m') - $startDate->format('m')) + 1;
                    if ($diffMonths != $courseDuration) {
                        $errors[] = "The difference between start and end dates must match the selected course duration ($courseDuration months).";
                    }
                }
            }
        }

        if (empty($errors)) {
            $stmt = $conn->prepare("INSERT INTO ATGET_Non_Schools_Result_Table 
                (Admission_No, Student_Name, Parent_Name, Course_Name, Course_Duration_In_Months, Course_Start_Date, Course_End_Date, Total_Marks_Obtained, Marks_In_Grade)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt === false) {
                $errors[] = "Prepare failed: " . $conn->error;
            } else {
                $stmt->bind_param("ssssissds", $admissionNo, $studentName, $parentName, $courseName, $courseDuration, $courseStart, $courseEnd, $totalMarks, $grade);
                try {
                    $stmt->execute();
                    $success = "Non-School Result updated successfully!";
                    $student = null; // clear student for next search
                    $formData = [];
                } catch (mysqli_sql_exception $e) {
                    if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
                        $errors[] = "Result already updated.";
                    } else {
                        $errors[] = "Database error: " . $e->getMessage();
                    }
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Update Non-School Result</title>
<style>
body { font-family: Arial, sans-serif; background: #f3f3f3; margin: 0; display: flex; justify-content: center; padding: 20px; }
.main-card { background: #fff; border-radius: 15px; padding: 25px; box-shadow: 0 0 20px rgba(0,0,0,0.15); width: 100%; max-width: 700px; }
.navbar { display: flex; justify-content: space-between; flex-wrap: wrap; background-color: #333; border-radius: 10px; overflow: hidden; margin-bottom: 20px; }
.navbar a { color: white; text-align: center; padding: 12px 10px; text-decoration: none; flex: 1; font-size: 15px; }
.navbar a:hover { background-color: #111; }
.navbar a.active { background-color: #04AA6D; }

h2, h3 { margin: 0; color: #333; }
.error, .success { padding: 10px; border-radius: 5px; margin-bottom: 15px; }
.error { background-color: #fdd; color: red; }
.success { background-color: #dff0d8; color: #3c763d; }

.search-bar { display: flex; gap: 10px; flex-wrap: nowrap; margin-bottom: 20px; }
.search-bar input { flex: 1; padding: 8px; font-size: 16px; border: 1px solid #ccc; border-radius: 5px; }
.search-bar button { flex-shrink: 0; }

form .form-section { display: flex; gap: 20px; flex-wrap: wrap; }
.left-col, .right-col { flex: 1 1 45%; }
.grade-row { width: 100%; }

form .form-row { display: flex; flex-wrap: wrap; margin-bottom: 15px; align-items: center; }
form .form-row label { flex: 1 0 45%; padding-right: 10px; font-weight: bold; }
form .form-row input, form .form-row select { flex: 1 1 50%; padding: 8px; border: 1px solid #ccc; border-radius: 5px; font-size: 16px; }
button { background-color: #4CAF50; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-size: 16px; }
button:hover { background-color: #45a049; }

.student-details { background-color: #eef6ff; border-left: 5px solid #4CAF50; padding: 15px; border-radius: 8px; margin-bottom: 20px; }

@media (max-width: 600px) {
    .navbar a { flex: 1 0 100%; border-bottom: 1px solid #444; }
    .left-col, .right-col { flex: 1 0 100%; }
    form .form-row label, form .form-row input, form .form-row select { flex: 1 0 100%; }
    .search-bar { flex-direction: column; }
    .search-bar button { width: 100%; }
}
</style>
</head>
<body>
<div class="main-card">

<div class="navbar">
    <a href="atgethomepage.html">Home</a>
    <a href="../login.html">Logout</a>
</div>

<h2>Update Non-School Result</h2><br>

<?php if (!empty($errors)): ?>
<div class="error">
    <?php foreach ($errors as $error): ?>
        <p><?= htmlspecialchars($error) ?></p>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($success): ?>
<div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<form method="POST" action="">
    <div class="search-bar">
        <input type="number" name="searchAdmissionNo" placeholder="Enter Admission No" required />
        <button type="submit">Search</button>
    </div>
</form>

<?php if ($student || !empty($formData)): ?>
<div class="student-details">
    <h3>Student Details</h3>
    <p><strong>Name:</strong> <?= htmlspecialchars($student['Student_Name'] ?? $_POST['studentName'] ?? '') ?></p>
    <p><strong>Parent Name:</strong> <?= htmlspecialchars($student['Parent_Name'] ?? $_POST['parentName'] ?? '') ?></p>
    <p><strong>School Name:</strong> <?= htmlspecialchars($student['School_Name'] ?? '') ?></p>
</div>

<form method="POST" action="">
    <input type="hidden" name="admissionNo" value="<?= htmlspecialchars($student['Admission_No'] ?? $_POST['admissionNo'] ?? '') ?>" />
    <input type="hidden" name="studentName" value="<?= htmlspecialchars($student['Student_Name'] ?? $_POST['studentName'] ?? '') ?>" />
    <input type="hidden" name="parentName" value="<?= htmlspecialchars($student['Parent_Name'] ?? $_POST['parentName'] ?? '') ?>" />

    <div class="form-section">
        <div class="left-col">
            <div class="form-row">
                <label for="courseName">Course Name:</label>
                <select id="courseName" name="courseName" required>
                    <option value="" disabled>-- Select Course --</option>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?= htmlspecialchars($c) ?>" <?= (isset($formData['courseName']) && $formData['courseName'] === $c) ? 'selected' : '' ?>><?= htmlspecialchars($c) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row">
                <label for="courseDuration">Course Duration (Months):</label>
                <select id="courseDuration" name="courseDuration" required>
                    <option value="" disabled>-- Select Duration --</option>
                    <?php foreach ($durations as $d): ?>
                        <option value="<?= htmlspecialchars($d) ?>" <?= (isset($formData['courseDuration']) && $formData['courseDuration'] == $d) ? 'selected' : '' ?>><?= htmlspecialchars($d) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-row">
                <label for="totalMarks">Total Marks Obtained:</label>
                <input type="number" id="totalMarks" name="totalMarks" step="0.01" min="0.01" value="<?= htmlspecialchars($formData['totalMarks'] ?? '') ?>" required>
            </div>
        </div>
        <div class="right-col">
            <div class="form-row">
                <label for="courseStart">Course Start Date:</label>
                <input type="month" id="courseStart" name="courseStart" value="<?= htmlspecialchars($formData['courseStart'] ?? '') ?>" required>
            </div>
            <div class="form-row">
                <label for="courseEnd">Course End Date:</label>
                <input type="month" id="courseEnd" name="courseEnd" value="<?= htmlspecialchars($formData['courseEnd'] ?? '') ?>" required>
            </div>
        </div>
    </div>

    <div class="form-row grade-row">
        <label for="grade">Grade:</label>
        <select id="grade" name="grade" required>
            <option value="" disabled>-- Select Grade --</option>
            <?php foreach ($grades as $g): ?>
                <option value="<?= htmlspecialchars($g) ?>" <?= (isset($formData['grade']) && $formData['grade'] === $g) ? 'selected' : '' ?>><?= htmlspecialchars($g) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <button type="submit" name="submitResult">Submit Result</button>
</form>
<?php endif; ?>
</div>
</body>
</html>

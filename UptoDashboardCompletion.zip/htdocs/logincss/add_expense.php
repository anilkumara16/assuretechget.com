<?php
require_once 'config.php';
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ---------------------------
// Session-based access control
// ---------------------------
if (!isset($_SESSION['username']) || $_SESSION['role'] !== 'Checker') {
    header("Location: logout.php");
    exit();
}

$errors = [];
$success = '';

// ---------------------------
// Fetch Academic Years
// ---------------------------
$academicYears = [];
$year_sql = "SELECT Academic_Year FROM ATGET_Academic_Year ORDER BY Academic_Year ASC";
$year_result = $conn->query($year_sql);
if ($year_result && $year_result->num_rows > 0) {
    while ($row = $year_result->fetch_assoc()) {
        $academicYears[] = $row['Academic_Year'];
    }
}

// ---------------------------
// Fetch Mode Transactions (Bank + CASH)
// ---------------------------
$modes = ['CASH'];
$bank_sql = "SELECT Alias_Name FROM ATGET_Bank_Details ORDER BY Alias_Name ASC";
$bank_result = $conn->query($bank_sql);
if ($bank_result && $bank_result->num_rows > 0) {
    while ($row = $bank_result->fetch_assoc()) {
        $modes[] = $row['Alias_Name'];
    }
}

// ---------------------------
// Handle POST request
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $academicYear     = $_POST['academicYear'] ?? '';
    $transactionDate  = $_POST['transactionDate'] ?? '';
    $modeTransaction  = $_POST['modeTransaction'] ?? '';
    $expenseAmount    = $_POST['expenseAmount'] ?? '';
    $particulars      = trim($_POST['particulars'] ?? '');

    // Validation
    if (!$academicYear || !$transactionDate || !$modeTransaction || !$expenseAmount || !$particulars) {
        $errors[] = "All fields are required.";
    }

    if (!is_numeric($expenseAmount) || floatval($expenseAmount) <= 0) {
        $errors[] = "Expense amount must be a positive number.";
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("INSERT INTO ATGET_Expense_Table 
            (Academic_Year, Transaction_Date, Mode_Transaction, Expense_Amount, Perticulars) 
            VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssds", $academicYear, $transactionDate, $modeTransaction, $expenseAmount, $particulars);

        if ($stmt->execute()) {
            $success = "Expense record added successfully!";
        } else {
            $errors[] = "Database error: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Expense</title>
<style>
body { font-family: Arial, sans-serif; background:#f3f3f3; margin:0; padding:0; display:flex; justify-content:center; }
.container { background:#fff; padding:25px; border-radius:15px; max-width:600px; width:95%; box-shadow:0 0 20px rgba(0,0,0,0.1); margin-top:20px; }
h2 { color:#2e7d32; text-align:center; margin-bottom:20px; }

/* NAVIGATION BAR */
.navbar { display:flex; justify-content:flex-end; gap:10px; margin-bottom:20px; flex-wrap:wrap; background:#333; border-radius:10px; padding:10px; }
.navbar a { text-decoration:none; padding:10px 16px; background:#333; color:white; border-radius:8px; font-weight:bold; transition:0.3s; }
.navbar a:hover { background:#04AA6D; }

/* FORM STYLING */
form .form-row {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 15px;
    align-items: center;
}

form .form-row label {
    flex: 0 0 35%; /* label takes 35% width */
    padding-right: 10px;
    font-weight: bold;
}

form .form-row input,
form .form-row select,
form .form-row textarea {
    flex: 1 0 65%; /* input/select/textarea takes remaining 65% */
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    min-width: 0;
}
button { background-color:#4CAF50; color:white; border:none; padding:10px 20px; border-radius:8px; cursor:pointer; font-size:16px; }
button:hover { background-color:#45a049; }
.error, .success { padding:10px; border-radius:5px; margin-bottom:15px; }
.error { background-color:#fdd; color:red; }
.success { background-color:#dff0d8; color:#3c763d; }

@media(max-width:480px){
    form .form-row { flex-direction:column; }
    form .form-row label { flex:1 0 100%; margin-bottom:5px; }
    .navbar { justify-content:center; }
}
</style>
</head>
<body>

<div class="container">
    <!-- NAVIGATION -->
    <div class="navbar">
        <a href="dashboard.php">Home</a>
        <a href="logout.php">Logout</a>
    </div>

    
    
    <h2> Add Expense</h2>

    <?php if(!empty($errors)): ?>
        <div class="error">
            <?php foreach($errors as $err): ?>
                <p><?= htmlspecialchars($err) ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if($success): ?>
        <div class="success">
            <p><?= htmlspecialchars($success) ?></p>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <div class="form-row">
            <label for="academicYear">Academic Year:</label>
            <select name="academicYear" id="academicYear" required>
                <option value="" disabled selected>-- Select Year --</option>
                <?php foreach($academicYears as $year): ?>
                    <option value="<?= htmlspecialchars($year) ?>"><?= htmlspecialchars($year) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-row">
            <label for="transactionDate">Transaction Date:</label>
            <input type="date" id="transactionDate" name="transactionDate" max="<?= date('Y-m-d') ?>" required />
        </div>

        <div class="form-row">
            <label for="modeTransaction">Mode of Transaction:</label>
            <select name="modeTransaction" id="modeTransaction" required>
                <option value="" disabled selected>-- Select Mode --</option>
                <?php foreach($modes as $mode): ?>
                    <option value="<?= htmlspecialchars($mode) ?>"><?= htmlspecialchars($mode) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-row">
            <label for="expenseAmount">Expense Amount:</label>
            <input type="number" step="0.01" id="expenseAmount" name="expenseAmount" min="0.01" required />
        </div>

        <div class="form-row">
            <label for="particulars">Particulars:</label>
            <textarea id="particulars" name="particulars" rows="3" required></textarea>
        </div>

        <div style="text-align:center;">
            <button type="submit">Submit Expense</button>
        </div>
    </form>
</div>

</body>
</html>

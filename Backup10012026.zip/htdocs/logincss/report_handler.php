<?php
require_once 'config.php';
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

function downloadCSV($filename, $data) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);
    $output = fopen('php://output', 'w');

    if (!empty($data)) {
        fputcsv($output, array_keys($data[0])); // Header row
        foreach ($data as $row) {
            fputcsv($output, $row);
        }
    }
    fclose($output);
    exit;
}

$reportType    = $_POST['ReportType'] ?? '';
$academicYear  = $_POST['academicYear'] ?? '';

if (!$reportType) die("Report Type is required.");

$data = [];
switch ($reportType) {

    //case 'Complete Receipt Details':
    //    $sql = "SELECT r.Receipt_No, r.Admission_No, s.Student_Name, s.Parent_Name, s.School_Name, 
    //                   r.Receipt_Amount, r.Receipt_Date, r.Academic_Year, r.Prepared_By, r.School_Name
    //            FROM ATGET_Receipt_Details r
    //            JOIN ATGET_Students_Details s ON r.Admission_No = s.Admission_No
    //            WHERE r.Academic_Year = ?";
    //    $stmt = $conn->prepare($sql);
    //    $stmt->bind_param("s", $academicYear);
    //   $stmt->execute();
    //    $result = $stmt->get_result();
    //    while ($row = $result->fetch_assoc()) $data[] = $row;
    //   downloadCSV("Complete_Receipt_Details_$academicYear.csv", $data);
     //   break;
    
	case 'Complete Receipt Details':
    $conn->query("SET SQL_BIG_SELECTS=1");
    $sql = "
        SELECT 
            r.Receipt_No,
            r.Admission_No,
            s.Student_Name,
            s.Parent_Name,
            s.School_Name,
            r.Receipt_Amount,
            r.Receipt_Date,
            r.Academic_Year,
            r.Prepared_By,
            r.School_Name,
            COALESCE(TRIM(c.Student_Current_Class), '') AS Student_Current_Class
        FROM 
            ATGET_Receipt_Details r
        JOIN 
            ATGET_Students_Details s 
            ON TRIM(r.Admission_No) = TRIM(s.Admission_No)
        LEFT JOIN 
            ATGET_Student_Current_Class_Details c 
            ON TRIM(r.Admission_No) = TRIM(c.Admission_No)
        WHERE 
            r.Academic_Year = ?
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $academicYear);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    downloadCSV("Complete_Receipt_Details_$academicYear.csv", $data);
    break;

	//case 'Complete Student Details':
    //	$sql = "SELECT * FROM ATGET_Students_Details WHERE Admission_Year = ?";
    //	$stmt = $conn->prepare($sql);
    //	$stmt->bind_param("s", $academicYear);
    //	$stmt->execute();
    //	$result = $stmt->get_result();
    //	while ($row = $result->fetch_assoc()) $data[] = $row;
    //	downloadCSV("Complete_Student_DB_$academicYear.csv", $data);
    //	break;
    
	case 'Complete Student Details':
    // Join both tables; if no match, show blank class
    $sql = "
        SELECT 
            s.*, 
            COALESCE(TRIM(c.Student_Current_Class), '') AS Student_Current_Class
        FROM 
            ATGET_Students_Details s
        LEFT JOIN 
            ATGET_Student_Current_Class_Details c
        ON 
            TRIM(s.Admission_No) = TRIM(c.Admission_No)
        WHERE 
            s.Admission_Year = ?
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $academicYear);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    downloadCSV("Complete_Student_DB_$academicYear.csv", $data);
    break;
        
    //case 'Admission No Wise Total Fee Paid':
     //   $sql = "SELECT 
     //               r.Admission_No,
     //               s.Student_Name,
     //               s.Parent_Name,
     //               s.School_Name,
     //               SUM(r.Receipt_Amount) AS Total_Paid
     //           FROM ATGET_Receipt_Details r
     //           JOIN ATGET_Students_Details s ON r.Admission_No = s.Admission_No
     //           WHERE r.Academic_Year = ?
     //           GROUP BY r.Admission_No, s.Student_Name, s.Parent_Name, s.School_Name
    //            ORDER BY s.School_Name, s.Student_Name";
    //    $stmt = $conn->prepare($sql);
    //   $stmt->bind_param("s", $academicYear);
    //    $stmt->execute();
    //    $result = $stmt->get_result();
    //    while ($row = $result->fetch_assoc()) $data[] = $row;
    //    downloadCSV("AdmissionNo_Wise_Total_Fee_$academicYear.csv", $data);
    //    break;
    
case 'Admission No Wise Total Fee Paid':
    // Allow big joins if needed
    $conn->query("SET SQL_BIG_SELECTS=1");

    $sql = "
        SELECT 
            r.Admission_No,
            s.Student_Name,
            s.Parent_Name,
            s.School_Name,
            COALESCE(TRIM(c.Student_Current_Class), '') AS Student_Current_Class,
            SUM(r.Receipt_Amount) AS Total_Paid
        FROM 
            ATGET_Receipt_Details r
        JOIN 
            ATGET_Students_Details s 
            ON TRIM(r.Admission_No) = TRIM(s.Admission_No)
        LEFT JOIN 
            ATGET_Student_Current_Class_Details c 
            ON TRIM(r.Admission_No) = TRIM(c.Admission_No)
        WHERE 
            r.Academic_Year = ?
        GROUP BY 
            r.Admission_No, s.Student_Name, s.Parent_Name, s.School_Name, c.Student_Current_Class
        ORDER BY 
            s.School_Name, s.Student_Name
    ";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $academicYear);
    $stmt->execute();
    $result = $stmt->get_result();

    $data = [];
    while ($row = $result->fetch_assoc()) {
        $data[] = $row;
    }

    downloadCSV("AdmissionNo_Wise_Total_Fee_$academicYear.csv", $data);
    break;
        
    default:
        die("Invalid Report Type selected.");
}
?>

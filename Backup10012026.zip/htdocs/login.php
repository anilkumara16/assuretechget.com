<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once('logincss/config.php'); // Include your DB config

$error = '';

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username']);
    $pass = trim($_POST['password']);

    
    if ($user === '' || $pass === '') {
        $error = "Username and password are required.";
    } else {
        // Prepare and execute the SQL query securely
        $sql = $conn->prepare("SELECT * FROM ATGET_Login_Creds WHERE username = ?");
        $sql->bind_param("s", $user);
        $sql->execute();
        $result = $sql->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $hashedPassword = $row['password'];
			
            
            
            // Use password_verify to check hashed password
            if (password_verify($pass, $hashedPassword)) {
                $_SESSION['username'] = $row['username'];
                $_SESSION['role'] = $row['Role'] ?? '';
                $_SESSION['loggedin'] = true;

                // Redirect to home
                header("Location: logincss/atgethome.php");
                exit();
            } else {
                $error = "Invalid username or password. You are being redirected to login page..!";
            }
        } else {
            $error = "Invalid username or password. You are being redirected to login page..!";
        }

        $sql->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>ATGET Login Form</title>
    <link rel="stylesheet" href="logincss/style.css">
    <link rel="icon" href="img/ATG Logo.png" type="image/png">
</head>

<body>
    <div class="main">
        <h1>Assure Tech Global Education Trust</h1>
        <h3>Enter your login credentials</h3>

        <?php if ($error): ?>
            <script>
                alert('<?= addslashes($error) ?>');
                window.location.href = 'login.php';
            </script>
        <?php endif; ?>

        <form action="" method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder="Enter your Username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Enter your Password" required>

            <div class="wrap">
                <button type="submit">Submit</button>
            </div>
        </form>

        <p>Forgot Password? <a href="reset_password.php">Reset Password.</a></p>
    </div>
</body>
</html>

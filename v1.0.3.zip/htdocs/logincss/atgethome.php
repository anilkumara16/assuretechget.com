<?php
require_once 'config.php';
session_start();

// --------------------
// Session-based access control
// --------------------
if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}


$username = htmlspecialchars($_SESSION['username']); // For welcome message
$role = $_SESSION['role']; // User role

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --------------------
// FETCH DATA FOR DASHBOARD ELEMENTS
// --------------------

// Fetch Academic Years
$academic_years = [];
$ay_sql = "SELECT Academic_Year FROM ATGET_Academic_Year ORDER BY Academic_Year DESC";
$ay_result = $conn->query($ay_sql);
if ($ay_result && $ay_result->num_rows > 0) {
    while ($row = $ay_result->fetch_assoc()) {
        $academic_years[] = $row['Academic_Year'];
    }
}
$selected_year = $_GET['academic_year'] ?? ($academic_years[0] ?? '');

// Fetch Schools & Summary
$schools = [];
$school_sql = "SELECT School_Names FROM ATGET_School_Names ORDER BY School_Names ASC";
$school_result = $conn->query($school_sql);
if ($school_result && $school_result->num_rows > 0) {
    while ($row = $school_result->fetch_assoc()) {
        $schools[] = $row['School_Names'];
    }
}

$table_data = [];
$total_students = 0;
$total_receipts = 0;

foreach ($schools as $school) {
    $students_q = $conn->query("SELECT COUNT(*) AS total FROM ATGET_Students_Details WHERE Admission_Year='$selected_year' AND School_Name='$school'");
    $students = ($students_q && $students_q->num_rows > 0) ? $students_q->fetch_assoc()['total'] : 0;

    $receipts_q = $conn->query("SELECT SUM(Receipt_Amount) AS total FROM ATGET_Receipt_Details WHERE Academic_Year='$selected_year' AND School_Name='$school'");
    $receipts = ($receipts_q && $receipts_q->num_rows > 0) ? $receipts_q->fetch_assoc()['total'] : 0;
    $receipts = $receipts ?: 0;

    if ($students > 0 || $receipts > 0) {
        $table_data[] = ['school' => $school, 'students' => $students, 'receipts' => $receipts];
        $total_students += $students;
        $total_receipts += $receipts;
    }
}

// Fetch Report Types dynamically
$report_types = [];
$report_sql = "SELECT Report_Name FROM ATGET_Report_Type ORDER BY Report_Name ASC";
$report_result = $conn->query($report_sql);
if ($report_result && $report_result->num_rows > 0) {
    while ($row = $report_result->fetch_assoc()) {
        $report_types[] = $row['Report_Name'];
    }
}

// Collection & Expense Summary
$collection_q = $conn->query("SELECT SUM(Receipt_Amount) AS total_collection FROM ATGET_Receipt_Details WHERE Academic_Year='$selected_year'");
$total_collection = ($collection_q && $collection_q->num_rows > 0) ? $collection_q->fetch_assoc()['total_collection'] : 0;
$total_collection = $total_collection ?: 0;

$expense_q = $conn->query("SELECT SUM(Expense_Amount) AS total_expense FROM ATGET_Expense_Table WHERE Academic_Year='$selected_year'");
$total_expense = ($expense_q && $expense_q->num_rows > 0) ? $expense_q->fetch_assoc()['total_expense'] : 0;
$total_expense = $total_expense ?: 0;

$balance = $total_collection - $total_expense;
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>ATGET Home</title>
<link rel="icon" href="img/ATG Logo.png" type="image/png">
<style>
    body { font-family: sans-serif; background: #f3f3f3; margin:0; padding:0; }
    .main { max-width: 900px; margin: 30px auto; background:#fff; padding:20px; border-radius:15px; box-shadow:0 0 20px rgba(0,0,0,0.1); }

    ul { list-style-type: none; margin: 0 0 20px 0; padding: 0; overflow: hidden; background-color: #333; border-radius:10px; }
    ul li a { display:block; color:white; text-align:center; padding:14px 16px; text-decoration:none; border-radius:10px; }
    ul li a.active, ul li a:hover { background-color:#04AA6D; color:white; }
    ul li.logout-item { float:right; }

    .menu-container { display:flex; gap:20px; flex-wrap:wrap; justify-content:space-between; margin-bottom:30px; }
    .menu-block { flex:1 1 45%; background-color:#4CAF50; border-radius:10px; overflow:hidden; }
    .menu-block > a { display:block; padding:14px; background-color:#388e3c; color:#fff; font-weight:bold; text-align:center; text-decoration:none; }
    .menu-block > a:hover { background-color:#2e7d32; }
    .submenu { list-style-type:none; margin:0; padding:0; background-color:#e8f5e9; }
    .submenu li a { display:block; padding:12px; text-decoration:none; color:#333; border-bottom:1px solid #ccc; }
    .submenu li a:hover { background-color:#c8e6c9; }
    .welcome { font-weight:bold; color:#333; margin-bottom:20px; }

    label { display:block; font-weight:bold; margin:10px 0 5px; }
    select { width:100%; padding:10px; font-size:16px; border-radius:5px; border:2px solid #4CAF50; background-color:#f9f9f9; }
    button { width:100%; padding:12px; margin-top:15px; font-size:16px; background-color:#4CAF50; color:white; border:none; border-radius:8px; cursor:pointer; }
    button:hover { background-color:#45a049; }

    table { width:100%; border-collapse:collapse; border-radius:10px; overflow:hidden; box-shadow:0 4px 6px rgba(0,0,0,0.1); margin-top:20px; }
    th, td { padding:12px; text-align:center; border-bottom:1px solid #ddd; }
    th { background:#4CAF50; color:white; }
    tr:last-child td { background:#e8f5e9; font-weight:bold; color:#2e7d32; }

    .report-section { display:flex; flex-wrap:wrap; align-items:center; gap:10px; margin-top:20px; }
    .report-section select { flex:1; min-width:200px; }
    .report-section button { flex:none; padding:10px 20px; font-size:16px; background:#4CAF50; color:white; border:none; border-radius:8px; cursor:pointer; }
    .report-section button:hover { background:#45a049; }

    @media screen and (max-width:700px) {
        .menu-container { flex-direction:column; }
        .menu-block { flex:1 1 100%; }
        .report-section { flex-direction:column; align-items:stretch; }
        .report-section button { width:100%; }
    }
</style>
</head>

<body>
<div class="main">

    <!-- Navigation Menu -->
    <ul>
        <li class="logout-item"><a href="logout.php">Logout</a></li>
    </ul>

    <!-- Welcome Message -->
    <div class="welcome">Welcome to Assure Tech Global Education Trust, <?= $username ?> !</div>

    <!-- Side-by-side Menus -->
    <div class="menu-container">
        <?php if($role === 'Maker' || $role === 'Admin' || $role === 'Franchise'): ?>
        <div class="menu-block">
            <a href="#">Student Management</a>
            <ul class="submenu">
                <li><a href="addStudent.php">Add Student Details</a></li>
                <li><a href="student_details.php">View/Update Student Details</a></li>
                <li><a href="update_school_result.php">Update School Results</a></li>
                <li><a href="update_non_school_results.php">Update Non-School Results</a></li>
         
            </ul>
        </div>
        <?php endif; ?>

        <?php if($role === 'Maker' || $role === 'Admin'): ?>
        <div class="menu-block">
            <a href="#">Receipt Management</a>
            <ul class="submenu">
                <li><a href="receipt_handler.php">Add Receipt</a></li>
                <li><a href="view_receipt.php">View Receipt</a></li>
                <li><a href="add_expense.php">Add Expense</a></li>
                <li><a href="cancel_receipt.php">Cancel Receipt</a></li>
                <li><a href="generate_certificate.php">Generate Certificate</a></li>
            </ul>
        </div>
        <?php endif; ?>
    </div>

    <!-- Academic Year Filter & Dashboard Table -->
    <?php if($role === 'Admin'): ?>
    <div class="filter">
        <form id="academicForm" method="GET">
            <label for="academic_year">Academic Year:</label>
            <select name="academic_year" id="academic_year">
                <?php foreach($academic_years as $year): ?>
                    <option value="<?= htmlspecialchars($year) ?>" <?= $selected_year==$year?'selected':'' ?>>
                        <?= htmlspecialchars($year) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>School Name</th>
                <th>Students</th>
                <?php if($role === 'Admin'): ?>
                <th>Receipts</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php foreach($table_data as $row): ?>
            <tr>
                <td><?= htmlspecialchars($row['school']) ?></td>
                <td><?= htmlspecialchars($row['students']) ?></td>
                <?php if( $role === 'Admin'): ?>
                <td><?= number_format($row['receipts'],2) ?></td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <tr>
                <td>Total</td>
                <td><?= $total_students ?></td>
                <?php if( $role === 'Admin'): ?>
                <td><?= number_format($total_receipts,2) ?></td>
                <?php endif; ?>
            </tr>
        </tbody>
    </table>

    <?php if($role === 'Admin'): ?>
    <!-- Collection & Expense Summary -->
    <table style="margin-top:30px;">
        <thead>
            <tr>
                <th>Total Collection</th>
                <th>Total Expense</th>
                <th>Difference</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td><?= number_format($total_collection, 2) ?></td>
                <td><?= number_format($total_expense, 2) ?></td>
                <td style="color: <?= $balance >= 0 ? 'green' : 'red' ?>; font-weight:bold;">
                    <?= number_format($balance, 2) ?>
                </td>
            </tr>
        </tbody>
    </table>
    <?php endif; ?>
    <?php endif; ?>

    <!-- Report Type Dropdown -->
    <?php if($role === 'Maker' || $role === 'Admin'): ?>
    <div class="report-section">
        <form method="POST" action="report_handler.php">
            <input type="hidden" name="academicYear" value="<?= htmlspecialchars($selected_year) ?>" />
            <label for="ReportType">Select Report Type:</label>
            <select name="ReportType" id="ReportType">
                <?php foreach($report_types as $report): ?>
                    <option value="<?= htmlspecialchars($report) ?>"><?= htmlspecialchars($report) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit">Download Report</button>
        </form>
    </div>
    <?php endif; ?>

</div>

<script>
// Auto-submit Academic Year selection without page flicker
document.getElementById('academic_year').addEventListener('change', function() {
    document.getElementById('academicForm').submit();
});
</script>

</body>
</html>

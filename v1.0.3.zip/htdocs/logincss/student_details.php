<?php
session_start(); // Start session

// --------------------
// Session-based access control
// --------------------
if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    // Not logged in, redirect to login page
    header("Location: ../login.php");
    exit();
}

// Optionally, get username and role
$username = htmlspecialchars($_SESSION['username']);
$role = $_SESSION['role'];

// Then include your config file
require_once 'config.php'; // DB connection


ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$student = null;
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['studentId'])) {
    // --- SEARCH LOGIC ---
    $admissionNo = $_GET['studentId'];
    $sql = "SELECT * FROM ATGET_Students_Details WHERE Admission_No = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $admissionNo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $student = $result->fetch_assoc();
    } else {
        $message = "** Student not found **";
    }

    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update') {
    // --- UPDATE LOGIC ---
    $admissionNo   = $_POST['admissionNo'] ?? '';
    $studentName   = $_POST['studentName'] ?? '';
    $parentName    = $_POST['parentName'] ?? '';
    $contactNumber = $_POST['contactDetails'] ?? '';
    $aadharNumber  = $_POST['aadharNumber'] ?? '';
    $address       = $_POST['address'] ?? '';

    if (empty($admissionNo)) {
        echo "<script>alert('Missing Admission Number.'); window.history.back();</script>";
        exit();
    }

    $sql = "UPDATE ATGET_Students_Details 
            SET Student_Name = ?, 
                Parent_Name = ?, 
                Contact_No = ?, 
                Student_Aadhar_No = ?, 
                Student_Address = ?
            WHERE Admission_No = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $studentName, $parentName, $contactNumber, $aadharNumber, $address, $admissionNo);

    if ($stmt->execute()) {
        echo "<script>alert('Student information updated successfully.'); window.location.href = 'student_details.php';</script>";
    } else {
        echo "<script>alert('Update failed: " . $stmt->error . "'); window.history.back();</script>";
    }

    $stmt->close();
    $conn->close();
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Student Info</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: sans-serif;
      background-color: #f3f3f3;
      display: flex;
      flex-direction: column;
      align-items: center;
      min-height: 100vh;
    }
    .main {
      background-color: #fff;
      border-radius: 15px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
      padding: 20px;
      width: 90%;
      max-width: 500px;
      margin-top: 30px;
    }
    ul {
      list-style-type: none;
      margin: 0 0 20px 0;
      padding: 0;
      overflow: hidden;
      background-color: #333;
      border-radius: 10px;
    }
    ul li { float: left; }
    ul li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }
    ul li a:hover:not(.active) { background-color: #111; }
    .active { background-color: #04AA6D; }

    label { display: block; margin-bottom: 5px; font-weight: bold; }
    input, textarea {
      width: 100%;
      padding: 8px;
      margin-bottom: 15px;
      box-sizing: border-box;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 16px;
    }
    .submit-section {
      display: flex;
      justify-content: space-between;
      gap: 10px;
      margin-top: 20px;
    }
    button {
      padding: 10px 15px;
      font-size: 16px;
      border-radius: 8px;
      border: none;
      background-color: #4CAF50;
      color: white;
      cursor: pointer;
      flex: 1;
    }
    button:hover { background-color: #45a049; }
    .cancel-button { background-color: #999; }
    .cancel-button:hover { background-color: #777; }
    #resultSection { color: red; text-align: center; margin-bottom: 10px; }

    @media (max-width: 500px) {
      .submit-section { flex-direction: column; }
      button { width: 100%; }
    }
  </style>

  <script>
    function enableEdit() {
      const fields = ['studentName', 'parentName', 'contactDetails', 'aadharNumber', 'address'];
      fields.forEach(id => document.getElementById(id).disabled = false);
      document.getElementById('editButton').style.display = 'none';
      document.getElementById('submitButton').style.display = 'inline-block';
      document.getElementById('cancelButton').style.display = 'inline-block';
    }
    function cancelEdit() {
      window.location.href = 'student_details.php';
    }
  </script>
</head>
<body>
  <div class="main">
    <ul>
      <li style="float:right"><a class="active" href="logout.php">Logout</a></li>
      <li style="float:right"><a class="active" href="atgethome.php">Home</a></li>
    </ul>

    <form action="student_details.php" method="GET">
      <label for="studentId">Search Student by ID:</label>
      <input type="number" id="studentId" name="studentId" placeholder="Enter Admission No" required />
      <button type="submit">Search</button>
    </form>

    <div id="resultSection"><?php echo htmlspecialchars($message); ?></div>

    <form action="student_details.php" method="POST" id="studentForm">
      <label for="admissionNo">Admission No:</label>
      <input type="text" id="admissionNo" value="<?php echo $student['Admission_No'] ?? ''; ?>" disabled />
      <input type="hidden" name="admissionNo" value="<?php echo $student['Admission_No'] ?? ''; ?>" />

      <label for="studentName">Student Name:</label>
      <input type="text" id="studentName" name="studentName" value="<?php echo $student['Student_Name'] ?? ''; ?>" disabled />

      <label for="parentName">Parent Name:</label>
      <input type="text" id="parentName" name="parentName" value="<?php echo $student['Parent_Name'] ?? ''; ?>" disabled />

      <label for="contactDetails">Contact Number:</label>
      <input type="text" id="contactDetails" name="contactDetails" 
             value="<?php echo $student['Contact_No'] ?? ''; ?>" 
             inputmode="numeric" pattern="\d*" maxlength="10" 
             oninput="this.value = this.value.replace(/[^0-9]/g, '')" disabled />

      <label for="aadharNumber">Aadhar Number:</label>
      <input type="text" id="aadharNumber" name="aadharNumber" 
             value="<?php echo $student['Student_Aadhar_No'] ?? ''; ?>" 
             inputmode="numeric" pattern="\d*" maxlength="12" 
             oninput="this.value = this.value.replace(/[^0-9]/g, '')" disabled />

      <label for="address">Address:</label>
      <textarea id="address" name="address" rows="3" disabled><?php echo $student['Student_Address'] ?? ''; ?></textarea>

      <label for="schoolName">School Name:</label>
      <input type="text" id="schoolName" name="schoolName" value="<?php echo $student['School_Name'] ?? ''; ?>" disabled />

      <label for="academicYear">Admission Academic Year:</label>
      <input type="text" id="academicYear" name="academicYear" value="<?php echo $student['Admission_Year'] ?? ''; ?>" disabled />

      <label for="completionStatus">Course completion Status:</label>
      <input type="text" id="completionStatus" name="completionStatus" value="<?php echo $student['Course_Completion_Academic_Year'] ?? ''; ?>" disabled />

      <input type="hidden" name="action" value="update" />

      <div class="submit-section">
        <button type="button" id="editButton" onclick="enableEdit()">Edit / Update Student Info</button>
        <button type="submit" id="submitButton" style="display: none;">Submit Changes</button>
        <button type="button" class="cancel-button" id="cancelButton" style="display: none;" onclick="cancelEdit()">Cancel</button>
      </div>
    </form>
  </div>
</body>
</html>

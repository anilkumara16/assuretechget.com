<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require('fpdf/fpdf.php');
require('phpqrcode/qrlib.php'); // adjust path
require('config.php'); // DB connection
session_start();

// ---------------------------
// Session-based access control
// ---------------------------
if (!isset($_SESSION['username'])) {
    header("Location: logout.php");
    exit();
}

// Initialize alert message
$alertMessage = '';

if(isset($_POST['admissionNo']) && !empty($_POST['admissionNo'])) {
    $admissionNo = $_POST['admissionNo'];

    // Fetch student details
    $stmt = $conn->prepare("SELECT Student_Name, Parent_Name, Course_Name, Course_Duration_In_Months, Course_Start_Date, Course_End_Date, Total_Marks_Obtained, Marks_In_Grade FROM ATGET_Non_Schools_Result_Table WHERE Admission_No = ?");
    $stmt->bind_param("s", $admissionNo);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();

    if(!$student) {
        $alertMessage = 'Student not found.';
    } else {
        // Generate PDF as string
        ob_start();
        $pdf = new FPDF('L','mm','A4');
        $pdf->AddPage();

    // Certificate template
    //$pdf->Image('certificate_template.png', 0, 0, 297, 210);
        
        
        // Add student details
        $pdf->SetFont('Arial','B',16);
        $pdf->SetXY(22, 60);
        $pdf->Cell(0,10,"Admission No : ".$admissionNo);
        $pdf->SetXY(118, 80);
        $pdf->Cell(0,10,$student['Student_Name']);
        $pdf->SetXY(118, 93);
        $pdf->Cell(0,10,$student['Parent_Name']);
        $pdf->SetXY(160, 105);
        $pdf->Cell(0,10,$student['Course_Name']);
        
        $courseStart = $student['Course_Start_Date'];
        $courseEnd = $student['Course_End_Date'];

        $startFormatted = strtoupper(date("M-Y", strtotime($courseStart . "-01")));
        $endFormatted   = strtoupper(date("M-Y", strtotime($courseEnd . "-01")));
        
        $pdf->SetXY(68, 132);
        $pdf->Cell(0,10,$student['Course_Duration_In_Months']."                             ".$startFormatted."     ".$endFormatted);
        $pdf->SetXY(123, 143);
        $pdf->Cell(0,10,$student['Marks_In_Grade']);
        $pdf->SetXY(150, 143);
        $pdf->Cell(0,10,$student['Total_Marks_Obtained']);

        // Generate QR code
        $qrData = "https://assuretechget.com/view_non_school_results.php?admissionNo=".$admissionNo;
        $tempFile = tempnam(sys_get_temp_dir(), 'qr_') . '.png';
        QRcode::png($qrData, $tempFile, QR_ECLEVEL_L, 3);
        $pdf->Image($tempFile, 260, 181, 25, 25);
        @unlink($tempFile);

        $pdfContent = $pdf->Output('S');
        $pdfEncoded = base64_encode($pdfContent);
        ob_end_clean();

        // Open PDF in new window
        echo "<script>
            var pdfWindow = window.open('', '_blank');
            pdfWindow.document.write('<iframe width=\"100%\" height=\"100%\" src=\"data:application/pdf;base64,{$pdfEncoded}\"></iframe>');
            pdfWindow.focus();
        </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Generate Certificate</title>
<style>
body { font-family: Arial, sans-serif; background:#f3f3f3; margin:0; padding:0; display:flex; justify-content:center; }
.container { background:#fff; padding:25px; border-radius:15px; max-width:600px; width:95%; box-shadow:0 0 20px rgba(0,0,0,0.1); margin-top:20px; }

/* NAVIGATION BAR */
.navbar { display:flex; justify-content:flex-end; gap:10px; margin-bottom:20px; flex-wrap:wrap; background:#333; border-radius:10px; padding:10px; }
.navbar a { text-decoration:none; padding:10px 16px; background:#333; color:white; border-radius:8px; font-weight:bold; transition:0.3s; }
.navbar a:hover { background:#04AA6D; }

/* FORM STYLING */
form .form-row {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 15px;
    align-items: center;
}

form .form-row label {
    flex: 0 0 35%;
    padding-right: 10px;
    font-weight: bold;
}

form .form-row input,
form .form-row select,
form .form-row textarea {
    flex: 1 0 65%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
    min-width: 0;
}
button { background-color:#4CAF50; color:white; border:none; padding:10px 20px; border-radius:8px; cursor:pointer; font-size:16px; }
button:hover { background-color:#45a049; }
h2 { color:#2e7d32; text-align:center; margin-bottom:20px; }

@media(max-width:480px){
    form .form-row { flex-direction:column; }
    form .form-row label { flex:1 0 100%; margin-bottom:5px; }
    .navbar { justify-content:center; }
}
</style>
</head>
<body>

<div class="container">
    <!-- NAVIGATION -->
    <div class="navbar">
        <a href="atgethome.php">Home</a>
        <a href="logout.php">Logout</a>
    </div>

    <h2>Generate Student Certificate</h2>

    <?php if($alertMessage): ?>
        <script>alert("<?= $alertMessage ?>");</script>
    <?php endif; ?>

    <form method="post">
        <div class="form-row">
            <label for="admissionNo">Admission Number:</label>
            <input type="text" name="admissionNo" id="admissionNo" placeholder="Enter Admission Number" required>
        </div>

        <div style="text-align:center;">
            <button type="submit">Generate PDF</button>
        </div>
    </form>
</div>

</body>
</html>

<?php
session_start();

// --------------------
// Session-based access control
// --------------------
if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    header("Location: ../login.php");
    exit();
}

$username = htmlspecialchars($_SESSION['username']);
$role = $_SESSION['role'];

require_once 'config.php'; // DB connection

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ---------------------------
// Initialize variables
// ---------------------------
$errors = [];
$success = '';
$academicYears = [];

// ---------------------------
// Fetch Academic Years
// ---------------------------
$year_sql = "SELECT Academic_Year FROM ATGET_Academic_Year ORDER BY Academic_Year ASC";
$year_result = $conn->query($year_sql);
if ($year_result && $year_result->num_rows > 0) {
    while ($row = $year_result->fetch_assoc()) {
        $academicYears[] = $row['Academic_Year'];
    }
}

// ---------------------------
// Handle POST submission
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $receiptNo    = trim($_POST['receiptNo'] ?? '');
    $academicYear = trim($_POST['academicYear'] ?? '');
    $preparedBy   = trim($_SESSION['username'] ?? '');

    // Basic validation
    if (empty($receiptNo)) {
        $errors[] = "Receipt Number is required.";
    }
    if (empty($academicYear)) {
        $errors[] = "Please select an Academic Year.";
    }

    if (empty($errors)) {
        $admissionNo = 'C';
        $receiptAmount = 0;
        $receiptDate = '2024-04-01';
        $schoolName = 'NA';

        $stmt = $conn->prepare("INSERT INTO ATGET_Receipt_Details 
            (Admission_No, Receipt_No, Receipt_Amount, Receipt_Date, Academic_Year, Prepared_By, School_Name)
            VALUES (?, ?, ?, ?, ?, ?, ?)");

        if ($stmt === false) {
            $errors[] = "Database prepare failed: " . $conn->error;
        } else {
            $stmt->bind_param("ssdssss", $admissionNo, $receiptNo, $receiptAmount, $receiptDate, $academicYear, $preparedBy, $schoolName);
            if ($stmt->execute()) {
                $success = "Receipt cancellation recorded successfully!";
            } else {
                $errors[] = "Database error: " . $stmt->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cancel Receipt</title>
<style>
/* --- Same style as receipt_handler.php --- */
body { font-family: Arial, sans-serif; background: #f3f3f3; margin: 0; display: flex; justify-content: center; padding: 20px; }
.main-card { background: #fff; border-radius: 15px; padding: 25px; box-shadow: 0 0 20px rgba(0,0,0,0.15); width: 100%; max-width: 600px; }
.navbar { display: flex; justify-content: space-between; background-color: #333; border-radius: 10px; overflow: hidden; margin-bottom: 20px; }
.navbar a { color: white; text-align: center; padding: 14px; text-decoration: none; flex: 1; }
.navbar a:hover { background-color: #111; }
.navbar a.active { background-color: #04AA6D; }
h2, h3 { margin: 0; color: #333; }
form .form-row { display: flex; flex-wrap: wrap; margin-bottom: 15px; align-items: center; }
form .form-row label { flex: 1 0 35%; padding-right: 10px; font-weight: bold; }
form .form-row input, form .form-row select { flex: 1 1 60%; padding: 8px; border: 1px solid #ccc; border-radius: 5px; font-size: 16px; }
button { background-color: #4CAF50; color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-size: 16px; }
button:hover { background-color: #45a049; }
.error, .success { padding: 10px; border-radius: 5px; margin-bottom: 15px; }
.error { background-color: #fdd; color: red; }
.success { background-color: #dff0d8; color: #3c763d; }
.button-group { display: flex; justify-content: center; gap: 15px; margin-top: 10px; }
</style>
</head>
<body>
<div class="main-card">

<!-- Navbar -->
<div class="navbar">
    <a href="atgethome.php">Home</a>
    <a href="#" class="active">Cancel Receipt</a>
    <a href="logout.php">Logout</a>
</div>

<h2>Cancel Receipt</h2><br>

<!-- Error Messages -->
<?php if (!empty($errors)): ?>
<div class="error">
    <?php foreach ($errors as $error): ?>
        <p><?= htmlspecialchars($error) ?></p>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Success Message -->
<?php if (!empty($success)): ?>
<div class="success">
    <p><?= htmlspecialchars($success) ?></p>
</div>
<div class="button-group">
    <button onclick="window.location.href=''">Cancel Another Receipt</button>
</div>
<?php else: ?>

<!-- Cancel Form -->
<form method="POST" action="">
    <div class="form-row">
        <label for="receiptNo">Receipt Number:</label>
        <input type="number" id="receiptNo" name="receiptNo" placeholder="Enter Receipt No" required />
    </div>

    <div class="form-row">
        <label for="academicYear">Academic Year:</label>
        <select id="academicYear" name="academicYear" required>
            <option value="" disabled selected>-- Select Year --</option>
            <?php foreach ($academicYears as $year): ?>
                <option value="<?= htmlspecialchars($year) ?>"><?= htmlspecialchars($year) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <button type="submit">Submit Cancellation</button>
</form>
<?php endif; ?>
</div>
</body>
</html>

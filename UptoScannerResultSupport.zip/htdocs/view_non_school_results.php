<?php
require_once 'config.php';
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$errors = [];
$student = null;
$resultData = null;
$success = '';

$admissionNo = null;

// --- Determine Admission No (from POST or GET) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['searchResult'])) {
    // Form was submitted — prefer this value (so user can override URL)
    $admissionNo = trim($_POST['admissionNo']);
} elseif (isset($_GET['admissionNo']) && trim($_GET['admissionNo']) !== '') {
    // No form submission — accept URL value
    $admissionNo = trim($_GET['admissionNo']);
}

// --- Handle Search if admissionNo exists ---
if ($admissionNo !== null) {
    if ($admissionNo === '') {
        $errors[] = "Admission number is required.";
    } elseif (!is_numeric($admissionNo) || $admissionNo < 0) {
        $errors[] = "Admission number must be a positive number.";
    } else {
        $stmt = $conn->prepare("SELECT Student_Name, Parent_Name, Course_Name, Course_Duration_In_Months, Course_Start_Date, Course_End_Date, Total_Marks_Obtained, Marks_In_Grade 
                                FROM ATGET_Non_Schools_Result_Table 
                                WHERE Admission_No = ?");
        $stmt->bind_param("s", $admissionNo);
        $stmt->execute();
        $res = $stmt->get_result();

        if ($res && $res->num_rows > 0) {
            $resultData = $res->fetch_assoc();
            $success = "Result found!";
        } else {
            $errors[] = "No result found for this admission number.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Non-School Result</title>
<style>
body { font-family: Arial, sans-serif; background: #f3f3f3; margin:0; display:flex; justify-content:center; padding:20px; }
.main-card { background:#fff; border-radius:15px; padding:25px; box-shadow:0 0 20px rgba(0,0,0,0.15); width:100%; max-width:600px; }

.header {
    text-align:center;
    font-size:26px;
    font-weight:bold;
    color:white;
    padding:15px 10px;
    border-radius:10px;
    background: linear-gradient(90deg, #4CAF50, #2196F3);
    box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    margin-bottom:20px;
    letter-spacing:1px;
}

h2,h3 { margin:0; color:#333; }
.error, .success { padding:10px; border-radius:5px; margin-bottom:15px; text-align:center; }
.error { background-color:#fdd; color:red; }
.success { background-color:#dff0d8; color:#3c763d; }

/* Search section: 2 rows x 2 cols */
.search-grid {
    display: grid;
    grid-template-columns: 50% 50%;
    grid-template-rows: auto auto;
    gap: 8px 10px;
    margin-bottom:20px;
}

.search-grid label, .search-grid .go-back-btn {
    display:flex;
    align-items:center;
    font-weight:bold;
}

.search-grid input{
    width:95%;
    padding:6px;
    border:1px solid #ccc;
    border-radius:5px;
    font-size:16px;
}

.search-grid button, .search-grid .go-back-btn {
    padding:8px;
    border:none;
    border-radius:5px;
    cursor:pointer;
    font-size:16px;
    width:100%;
}

.search-grid button { background-color:#4CAF50; color:white; }
.search-grid button:hover { background-color:#45a049; }
.search-grid .go-back-btn { background:#2196F3; color:white; }
.search-grid .go-back-btn:hover { background:#0b7dda; }

.result-container {
    display:flex;
    justify-content:space-between;
    gap:15px;
    margin-top:20px;
}

.result-card {
    background:#eef6ff;
    border-left:5px solid #4CAF50;
    padding:15px;
    border-radius:8px;
    flex:1 1 48%;
}

.result-card p { display:flex; justify-content:space-between; margin:5px 0; }
.result-card p span:first-child { font-weight:bold; }

.animation-container {
    text-align:center;
    margin-top:20px;
    font-size:18px;
    font-weight:bold;
    color:white;
    background:green;
    padding:10px;
    border-radius:8px;
    animation: blink 5s infinite;
}

@keyframes blink {
    0%,50%,100% { background:green; color:white; transform: scale(1); }
    25%,75% { background:white; color:green; transform: scale(1.05); }
}

@media (max-width:700px) {
    .result-container { flex-direction:column; }
    .result-card { flex:1 1 100%; margin-bottom:15px; }
    .search-grid { grid-template-columns: 50% 50%; grid-template-rows: auto auto auto auto; }
}
</style>
</head>
<body>
<div class="main-card">

<div class="header">Assure Tech Global Education Trust(R)</div>

<h2><center>View Result</center></h2><br>

<?php if (!empty($errors)): ?>
<div class="error">
    <?php foreach($errors as $e): ?>
        <p><?= htmlspecialchars($e) ?></p>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if($success): ?>
<div class="success"><?= htmlspecialchars($success) ?> 🎉</div>
<?php endif; ?>

<form method="POST" action="">
    <div class="search-grid">
        <!-- Row 1: labels -->
        <label for="admissionNo">Admission No:</label>
        <div></div>

        <!-- Row 2: input & search/go-back buttons -->
        <input type="number" min="0" name="admissionNo" id="admissionNo" required value="<?= htmlspecialchars($admissionNo ?? '') ?>">

        <div style="display:flex; gap:5px;">
            <button type="submit" name="searchResult">Search</button>
            <button type="button" class="go-back-btn" onclick="window.location.href='index.html'">Go Back</button>
        </div>
    </div>
</form>

<?php if($resultData): ?>
<div class="result-container">
    <div class="result-card">
        <h3>Student Details</h3>
        <p><span>Name:</span> <span><?= htmlspecialchars($resultData['Student_Name']) ?></span></p>
        <p><span>Parent Name:</span> <span><?= htmlspecialchars($resultData['Parent_Name']) ?></span></p>
    </div>
    <div class="result-card">
        <h3>Result Details</h3>
        <p><span>Course Name:</span> <span><?= htmlspecialchars($resultData['Course_Name']) ?></span></p>
        <p><span>Duration (Months):</span> <span><?= htmlspecialchars($resultData['Course_Duration_In_Months']) ?></span></p>
        <p><span>Start Date:</span> <span><?= htmlspecialchars(date("M-Y", strtotime($resultData['Course_Start_Date']))) ?></span></p>
        <p><span>End Date:</span> <span><?= htmlspecialchars(date("M-Y", strtotime($resultData['Course_End_Date']))) ?></span></p>
    </div>
</div>

<div class="animation-container">
    Total Marks: <?= htmlspecialchars($resultData['Total_Marks_Obtained']) ?> | Grade: <?= htmlspecialchars($resultData['Marks_In_Grade']) ?> 🎉 Congratulations!
</div>
<?php endif; ?>

</div>
</body>
</html>

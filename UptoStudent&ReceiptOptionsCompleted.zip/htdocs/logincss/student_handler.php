<?php
require_once 'config.php';
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ---------------------------
// Initialize variables
// ---------------------------
$errors = [];
$success = '';
$student = null;
$makers = [];
$academicYears = [];

// ---------------------------
// Fetch Makers
// ---------------------------
$maker_sql = "SELECT Username FROM ATGET_Login_Creds WHERE Role = 'Maker'";
$maker_result = $conn->query($maker_sql);
if ($maker_result && $maker_result->num_rows > 0) {
    while ($row = $maker_result->fetch_assoc()) {
        $makers[] = $row['Username'];
    }
}

// ---------------------------
// Fetch Academic Years
// ---------------------------
$year_sql = "SELECT Academic_Year FROM ATGET_Academic_Year ORDER BY Academic_Year ASC";
$year_result = $conn->query($year_sql);
if ($year_result && $year_result->num_rows > 0) {
    while ($row = $year_result->fetch_assoc()) {
        $academicYears[] = $row['Academic_Year'];
    }
}

// ---------------------------
// Convert number to Indian words
// ---------------------------
function numberToIndianWords($num)
{
    $num = (int)$num;
    if ($num == 0) return 'Zero';

    $words1 = [
        0 => '',
        1 => 'One', 2 => 'Two', 3 => 'Three', 4 => 'Four', 5 => 'Five',
        6 => 'Six', 7 => 'Seven', 8 => 'Eight', 9 => 'Nine', 10 => 'Ten',
        11 => 'Eleven', 12 => 'Twelve', 13 => 'Thirteen', 14 => 'Fourteen',
        15 => 'Fifteen', 16 => 'Sixteen', 17 => 'Seventeen', 18 => 'Eighteen', 19 => 'Nineteen'
    ];

    $words2 = [
        2 => 'Twenty', 3 => 'Thirty', 4 => 'Forty', 5 => 'Fifty',
        6 => 'Sixty', 7 => 'Seventy', 8 => 'Eighty', 9 => 'Ninety'
    ];

    $units = ['', 'Thousand', 'Lakh', 'Crore'];

    $num_str = (string)$num;
    $length = strlen($num_str);

    $parts = [];
    if ($length > 3) {
        $parts[] = substr($num_str, -3);
        $num_str = substr($num_str, 0, -3);
    } else {
        $parts[] = $num_str;
        $num_str = '';
    }

    while (strlen($num_str) > 0) {
        $parts[] = substr($num_str, -2);
        $num_str = substr($num_str, 0, -2);
    }

    $parts = array_reverse($parts);
    $wordArr = [];

    foreach ($parts as $i => $part) {
        $partNum = (int)$part;
        if ($partNum == 0) continue;

        $str = '';
        if ($partNum < 20) {
            $str = $words1[$partNum];
        } else {
            $tens = (int)($partNum / 10);
            $ones = $partNum % 10;
            $str = ($words2[$tens] ?? '') . ' ' . ($words1[$ones] ?? '');
        }

        if ($i < count($parts) - 1 && $partNum > 0) {
            $str .= ' ' . $units[count($parts) - 1 - $i];
        }

        $wordArr[] = trim($str);
    }

    return trim(implode(' ', $wordArr));
}

// ---------------------------
// Handle POST requests
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // --------- Search Student ----------
    if (isset($_POST['searchAdmissionNo'])) {
        $admissionNo = trim($_POST['searchAdmissionNo']);
        if (empty($admissionNo)) {
            $errors[] = "Admission Number is required for search.";
        } else {
            $stmt = $conn->prepare("SELECT * FROM ATGET_Students_Details WHERE Admission_No = ?");
            $stmt->bind_param("s", $admissionNo);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $student = $result->fetch_assoc();
            } else {
                $errors[] = "Student with Admission No '$admissionNo' not found.";
            }
        }
    }

    // --------- Submit Receipt ----------
    elseif (isset($_POST['receiptNo'])) {
        $admissionNo   = trim($_POST['admissionNo'] ?? '');
        $receiptNo     = trim($_POST['receiptNo'] ?? '');
        $receiptAmount = trim($_POST['receiptAmount'] ?? '');
        $receiptDate   = trim($_POST['receiptDate'] ?? '');
        $academicYear  = trim($_POST['academicYear'] ?? '');
        $preparedBy    = trim($_POST['preparedBy'] ?? '');
        $approvedBy    = 'PENDING';

        // Date validation
        $minDate = strtotime('2025-04-01');
        $maxDate = strtotime(date('Y-m-d'));
        $inputDate = strtotime($receiptDate);
        if ($inputDate < $minDate || $inputDate > $maxDate) {
            $errors[] = "Receipt date must be between 01-Apr-2025 and today.";
        }

        // Required fields check
        if (!$admissionNo || !$receiptNo || !$receiptAmount || !$receiptDate || !$academicYear || !$preparedBy) {
            $errors[] = "All fields are required for receipt submission.";
        }

        // Insert receipt if no errors
        if (empty($errors)) {
            $stmt = $conn->prepare("INSERT INTO ATGET_Receipt_Details 
                (Admission_No, Receipt_No, Receipt_Amount, Receipt_Date, Academic_Year, Prepared_By, Approved_By)
                VALUES (?, ?, ?, ?, ?, ?, ?)");
            if ($stmt === false) {
                $errors[] = "Prepare failed: " . $conn->error;
            } else {
                $stmt->bind_param("ssdssss", $admissionNo, $receiptNo, $receiptAmount, $receiptDate, $academicYear, $preparedBy, $approvedBy);
                if ($stmt->execute()) {
                    $success = "Receipt submitted successfully!";
                    $stmt2 = $conn->prepare("SELECT * FROM ATGET_Students_Details WHERE Admission_No = ?");
                    $stmt2->bind_param("s", $admissionNo);
                    $stmt2->execute();
                    $studentResult = $stmt2->get_result();
                    if ($studentResult && $studentResult->num_rows > 0) {
                        $student = $studentResult->fetch_assoc();
                    }
                } else {
                    $errors[] = "Database error: " . $stmt->error;
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Receipt Handler</title>
<style>
body {
    font-family: Arial, sans-serif;
    background: #f3f3f3;
    margin: 0;
    display: flex;
    justify-content: center;
    padding: 20px;
}

.main-card {
    background: #fff;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 0 20px rgba(0,0,0,0.15);
    width: 100%;
    max-width: 600px;
}

.navbar {
    display: flex;
    justify-content: space-between;
    background-color: #333;
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 20px;
}

.navbar a {
    color: white;
    text-align: center;
    padding: 14px;
    text-decoration: none;
    flex: 1;
}

.navbar a:hover { background-color: #111; }
.navbar a.active { background-color: #04AA6D; }

h2, h3 { margin: 0; color: #333; }

form .form-row {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 15px;
    align-items: center;
}
form .form-row label {
    flex: 1 0 35%;
    padding-right: 10px;
    font-weight: bold;
}
form .form-row input,
form .form-row select {
    flex: 1 1 60%;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    font-size: 16px;
}

button {
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
}
button:hover { background-color: #45a049; }

.error, .success {
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 15px;
}
.error { background-color: #fdd; color: red; }
.success { background-color: #dff0d8; color: #3c763d; }

.button-group {
    display: flex;
    justify-content: center;
    gap: 15px;
    margin-top: 10px;
}

/* ----------------------------
   Print Styles
---------------------------- */
@media print {
    body * { visibility: hidden; }
    #printArea, #printArea * { visibility: visible; }
    #printArea {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        margin: 0;
        padding: 0;
    }
    #printArea table {
        border-collapse: collapse;
        width: 100%;
    }
    #printArea th, #printArea td {
        border: 1px solid black;
        padding: 5px;
        vertical-align: top;
    }
    @page { margin: 5mm; }
}
</style>
</head>
<body>
<div class="main-card">

<!-- Navbar -->
<div class="navbar">
    <a href="atgethomepage.html" class="active">Home</a>
    <a href="../login.html">Logout</a>
</div>

<h2>Add Receipt</h2><br>

<!-- Error Messages -->
<?php if (!empty($errors)): ?>
<div class="error">
    <?php foreach ($errors as $error): ?>
        <p><?= htmlspecialchars($error) ?></p>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- SUCCESS VIEW -->
<?php if ($success && $student): 
$studentName   = htmlspecialchars($student['Student_Name'] ?? '');
$parentName    = htmlspecialchars($student['Parent_Name'] ?? '');
$contactNo     = htmlspecialchars($student['Contact_No'] ?? '');
$schoolName    = htmlspecialchars($student['School_Name'] ?? '');
$receiptNo     = htmlspecialchars($_POST['receiptNo'] ?? '');
$receiptAmount = floatval($_POST['receiptAmount'] ?? 0);
    
$receiptDateRaw = $_POST['receiptDate'] ?? '';
$receiptDate = $receiptDateRaw ? date('d-m-Y', strtotime($receiptDateRaw)) : '';
    
$academicYear  = htmlspecialchars($_POST['academicYear'] ?? '');
$preparedBy    = htmlspecialchars($_POST['preparedBy'] ?? '');
$amountInWords = numberToIndianWords($receiptAmount) . " only";
?>

<!-- Printable Receipt FIRST -->
<div id="printArea">
    <table>
        <tr>
            <td colspan="2" style="text-align:center;">
                <div style="display:flex; align-items:center; justify-content:center; gap:10px;">
                    <img src="Container/ATG Logo.png" alt="Logo" style="height:80px;">
                    <div>
                        <h2>Assure Tech Global Education Trust(R)</h2>
                        <h3>Fee Receipt</h3>
                    </div>
                </div>
            </td>
        </tr>
        <tr>
            <td>
                <h3>Student Details</h3>
                <p><strong>Student Name:</strong> <?= $studentName ?></p>
                <p><strong>Parent Name:</strong> <?= $parentName ?></p>
                <p><strong>Contact No:</strong> <?= $contactNo ?></p>
                <p><strong>School Name:</strong> <?= $schoolName ?></p>
            </td>
            <td>
                <h3>Receipt Details</h3>
                <p><strong>Receipt No:</strong> <?= $receiptNo ?></p>
                <p><strong>Receipt Amount:</strong> ₹<?= number_format($receiptAmount, 2) ?>/-</p>
                <p><strong>Receipt Date:</strong> <?= $receiptDate ?></p>
                <p><strong>Academic Year:</strong> <?= $academicYear ?></p>
            </td>
        </tr>
        <tr>
            <td><strong>Amount in Words:</strong> <?= $amountInWords ?></td>
            <td style="text-align:center;"><br><strong>Signature</strong><br>(ATGET)</td>
        </tr>
    </table>
</div>

<!-- THEN SUCCESS MESSAGE -->
<div class="success">
    <p><?= $success ?></p>
</div>

<!-- THEN BUTTONS SIDE BY SIDE -->
<div class="button-group">
    <button id="addAnotherBtn">Add Another Receipt</button>
    <button onclick="window.print()">Print Receipt</button>
</div>

<script>
document.getElementById('addAnotherBtn').addEventListener('click', function() {
    window.location.href = '';
});
</script>

<?php else: ?>

<!-- SEARCH FORM -->
<form method="POST" action="">
    <div class="form-row">
        <label for="searchAdmissionNo">Admission Number:</label>
        <input type="number" id="searchAdmissionNo" name="searchAdmissionNo" placeholder="Enter Admission No" required />
    </div>
    <button type="submit">Search</button>
</form>

<!-- RECEIPT FORM -->
<?php if ($student): ?>
<hr style="margin:25px 0; border:1px solid #eee;">
<h3>Student Details</h3>
<p><strong>Name:</strong> <?= htmlspecialchars($student['Student_Name']) ?></p>
<p><strong>Parent Name:</strong> <?= htmlspecialchars($student['Parent_Name']) ?></p>
<p><strong>Contact No:</strong> <?= htmlspecialchars($student['Contact_No']) ?></p>
<p><strong>School Name:</strong> <?= htmlspecialchars($student['School_Name']) ?></p>

<form method="POST" action="">
    <input type="hidden" name="admissionNo" value="<?= htmlspecialchars($student['Admission_No']) ?>" />

    <div class="form-row">
        <label for="receiptNo">Receipt No:</label>
        <input type="number" id="receiptNo" name="receiptNo" required />
    </div>

    <div class="form-row">
        <label for="receiptAmount">Receipt Amount:</label>
        <input type="number" step="0.01" id="receiptAmount" name="receiptAmount" required />
    </div>

    <div class="form-row">
        <label for="receiptDate">Receipt Date:</label>
        <input type="date" id="receiptDate" name="receiptDate" min="2025-04-01" max="<?= date('Y-m-d') ?>" required />
    </div>

    <div class="form-row">
        <label for="academicYear">Academic Year:</label>
        <select id="academicYear" name="academicYear" required>
            <option value="" disabled selected>-- Select Year --</option>
            <?php foreach ($academicYears as $year): ?>
                <option value="<?= htmlspecialchars($year) ?>"><?= htmlspecialchars($year) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div class="form-row">
        <label for="preparedBy">Prepared By:</label>
        <select id="preparedBy" name="preparedBy" required>
            <option value="" disabled selected>-- Select Maker --</option>
            <?php foreach ($makers as $maker): ?>
                <option value="<?= htmlspecialchars($maker) ?>" <?= ($_SESSION['username'] ?? '') === $maker ? 'selected' : '' ?>><?= htmlspecialchars($maker) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <button type="submit">Submit Receipt</button>
</form>
<?php endif; ?>
<?php endif; ?>
</div>
</body>
</html>

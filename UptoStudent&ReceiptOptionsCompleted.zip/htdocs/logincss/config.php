<?php
// config.php
$servername = "sql206.infinityfree.com";
$username = "if0_40080693"; // Replace with your database username
$password = "wQ0Def2wSfa"; // Replace with your database password
$dbname = "if0_40080693_ATGETDB"; // Replace with your database name

// Optional: You can also create the connection here and reuse it
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<?php
ob_start();
require_once 'config.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- SEARCH LOGIC ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['studentId'])) {
    $admissionNo = $_GET['studentId'];

    $sql = "SELECT * FROM ATGET_Students_Details WHERE Admission_No = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $admissionNo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $student = $result->fetch_assoc();
        $queryParams = http_build_query([
            'admission_no'   => $student['Admission_No'],
            'student_name'   => $student['Student_Name'],
            'parent_name'    => $student['Parent_Name'],
            'contact_number' => $student['Contact_No'],
            'aadhar_number'  => $student['Student_Aadhar_No'],
            'address'        => $student['Student_Address'],
            'school_name'    => $student['School_Name'],
            'academic_year'  => $student['Admission_Year'],
            'completion_status'  => $student['Course_Completion_Academic_Year']
        ]);
        header("Location: studentDetails.html?$queryParams");
    } else {
        header("Location: studentDetails.html?Student%20not%20found");
    }

    $stmt->close();
    $conn->close();
    ob_end_flush();
    exit();
}

// --- INSERT or UPDATE LOGIC ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    $studentName   = $_POST['studentName'] ?? '';
    $parentName    = $_POST['parentName'] ?? '';
    $contactNumber = $_POST['contactDetails'] ?? '';
    $aadharNumber  = $_POST['aadharNumber'] ?? '';
    $address       = $_POST['address'] ?? '';
    $schoolName    = $_POST['schoolName'] ?? '';
    $academicYearRaw = $_POST['academicYear'] ?? '';
    $academicYear  = str_replace('-', '', $academicYearRaw);

    if ($action === 'insert') {
        // STEP 1: Get Campus_No
        $campusSql = "SELECT Campus_No FROM ATGET_School_Names WHERE School_Names = ?";
        $campusStmt = $conn->prepare($campusSql);
        $campusStmt->bind_param("s", $schoolName);
        $campusStmt->execute();
        $campusResult = $campusStmt->get_result();

        if (!$campusResult || $campusResult->num_rows === 0) {
            echo "<script>alert('Invalid School Name.'); window.history.back();</script>";
            exit();
        }

        $campusRow = $campusResult->fetch_assoc();
        $campusNo = str_pad($campusRow['Campus_No'], 3, '0', STR_PAD_LEFT); // 3 digits

        // STEP 2: Generate count based on prefix
        $prefix = $academicYear . $campusNo; // 9-digit prefix
        $countSql = "SELECT COUNT(*) as total FROM ATGET_Students_Details WHERE Admission_No LIKE CONCAT(?, '%')";
        $countStmt = $conn->prepare($countSql);
        $countStmt->bind_param("s", $prefix);
        $countStmt->execute();
        $countResult = $countStmt->get_result();

        $totalCount = 0;
        if ($countResult && $row = $countResult->fetch_assoc()) {
            $totalCount = intval($row['total']) + 1;
        }

        $countPadded = str_pad($totalCount, 5, '0', STR_PAD_LEFT); // Remaining 5 digits
        $admissionNo = $prefix . $countPadded; // Final 14-digit Admission No

        // STEP 3: Insert into DB
        $courseCompletionYear = 'ACTIVE';

        $sql = "INSERT INTO ATGET_Students_Details 
            (Admission_No, Student_Name, Parent_Name, Contact_No, Student_Aadhar_No, Student_Address, School_Name, Admission_Year, Course_Completion_Academic_Year)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssssss", $admissionNo, $studentName, $parentName, $contactNumber, $aadharNumber, $address, $schoolName, $academicYearRaw, $courseCompletionYear);

        if ($stmt->execute()) {
            echo "<script>alert('Student added successfully. Admission No: $admissionNo'); window.location.href = 'addStudent.php';</script>";
        } else {
            echo "<script>alert('Error adding student: " . $stmt->error . "'); window.history.back();</script>";
        }

        $stmt->close();
        $countStmt->close();
        $campusStmt->close();
        $conn->close();
        ob_end_flush();
        exit();
    } elseif ($action === 'update') {
        $admissionNo   = $_POST['admissionNo'] ?? '';

        if (empty($admissionNo)) {
            echo "<script>alert('Missing Admission Number.'); window.history.back();</script>";
            exit();
        }

        $sql = "UPDATE ATGET_Students_Details 
                SET Student_Name = ?, 
                    Parent_Name = ?, 
                    Contact_No = ?, 
                    Student_Aadhar_No = ?, 
                    Student_Address = ?
                WHERE Admission_No = ?";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssss", $studentName, $parentName, $contactNumber, $aadharNumber, $address, $admissionNo);

        if ($stmt->execute()) {
            echo "<script>alert('Student information updated successfully.'); window.location.href = 'studentDetails.html';</script>";
        } else {
            echo "<script>alert('Update failed: " . $stmt->error . "'); window.history.back();</script>";
        }

        $stmt->close();
        $conn->close();
        ob_end_flush();
        exit();
    } else {
        echo "<script>alert('Invalid action.'); window.history.back();</script>";
        exit();
    }
}

echo "Invalid request.";
$conn->close();
exit();

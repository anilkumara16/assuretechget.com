<?php
ob_start();
require_once 'config.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- SEARCH LOGIC ---
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['studentId'])) {
    $admissionNo = $_GET['studentId'];

    $sql = "SELECT * FROM ATGET_Students_Details WHERE Admission_No = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $admissionNo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows > 0) {
        $student = $result->fetch_assoc();
        $queryParams = http_build_query([
            'admission_no'       => $student['Admission_No'],
            'student_name'       => $student['Student_Name'],
            'parent_name'        => $student['Parent_Name'],
            'contact_number'     => $student['Contact_No'],
            'aadhar_number'      => $student['Student_Aadhar_No'],
            'address'            => $student['Student_Address'],
            'school_name'        => $student['School_Name'],
            'academic_year'      => $student['Admission_Year'],
            'completion_status'  => $student['Course_Completion_Academic_Year']
        ]);
        header("Location: mark_completion.html?$queryParams");
    } else {
        header("Location: mark_completion.html?Student%20not%20found");
    }

    $stmt->close();
    $conn->close();
    ob_end_flush();
    exit();
}
// --- COMPLETION LOGIC ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admissionNo'])) {
    $admissionNo = $_POST['admissionNo'];
    $currentAcademicYear = date('dmY'); // Use ddMMyyyy format

    // First, check if the student's status is ACTIVE
    $checkSql = "SELECT Course_Completion_Academic_Year FROM ATGET_Students_Details WHERE Admission_No = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("s", $admissionNo);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult && $checkResult->num_rows > 0) {
        $row = $checkResult->fetch_assoc();
        $status = strtoupper(trim($row['Course_Completion_Academic_Year']));

        if ($status === 'ACTIVE') {
            // Proceed with marking as completed
            $updateSql = "UPDATE ATGET_Students_Details SET Course_Completion_Academic_Year = ? WHERE Admission_No = ?";
            $updateStmt = $conn->prepare($updateSql);
            $updateStmt->bind_param("ss", $currentAcademicYear, $admissionNo);

            if ($updateStmt->execute()) {
                echo "<script>alert('Marked as completed for academic year $currentAcademicYear'); window.location.href = 'mark_completion.html';</script>";
            } else {
                echo "<script>alert('Error marking completion.'); window.history.back();</script>";
            }

            $updateStmt->close();
        } else {
            echo "<script>alert('Cannot mark as completed. Status is \"$status\". Only ACTIVE students can be marked as completed.'); window.history.back();</script>";
        }
    } else {
        echo "<script>alert('Student not found.'); window.history.back();</script>";
    }

    $checkStmt->close();
    $conn->close();
    ob_end_flush();
    exit();
}

echo "<script>alert('Invalid request.'); window.history.back();</script>";
$conn->close();
exit();
?>

<?php
require_once 'config.php';
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Fetch Academic Years
$academic_years = [];
$ay_sql = "SELECT Academic_Year FROM ATGET_Academic_Year ORDER BY Academic_Year DESC";
$ay_result = $conn->query($ay_sql);
if ($ay_result && $ay_result->num_rows > 0) {
    while ($row = $ay_result->fetch_assoc()) {
        $academic_years[] = $row['Academic_Year'];
    }
}
$selected_year = $_GET['academic_year'] ?? ($academic_years[0] ?? '');

// Fetch Schools & Summary
$schools = [];
$school_sql = "SELECT School_Names FROM ATGET_School_Names ORDER BY School_Names ASC";
$school_result = $conn->query($school_sql);
if ($school_result && $school_result->num_rows > 0) {
    while ($row = $school_result->fetch_assoc()) {
        $schools[] = $row['School_Names'];
    }
}

$table_data = [];
$total_students = 0;
$total_receipts = 0;

foreach ($schools as $school) {
    $students_q = $conn->query("SELECT COUNT(*) AS total FROM ATGET_Students_Details WHERE Admission_Year='$selected_year' AND School_Name='$school'");
    $students = ($students_q && $students_q->num_rows > 0) ? $students_q->fetch_assoc()['total'] : 0;

    $receipts_q = $conn->query("SELECT SUM(Receipt_Amount) AS total FROM ATGET_Receipt_Details WHERE Academic_Year='$selected_year' AND School_Name='$school'");
    $receipts = ($receipts_q && $receipts_q->num_rows > 0) ? $receipts_q->fetch_assoc()['total'] : 0;
    $receipts = $receipts ?: 0;

    if ($students > 0 || $receipts > 0) {
        $table_data[] = ['school' => $school, 'students' => $students, 'receipts' => $receipts];
        $total_students += $students;
        $total_receipts += $receipts;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ATGET Dashboard</title>
<style>
* { box-sizing:border-box; margin:0; padding:0; font-family:sans-serif; }
body { background:#f3f3f3; }
.main { max-width:900px; margin:30px auto; background:#fff; padding:20px; border-radius:15px; box-shadow:0 0 20px rgba(0,0,0,0.1); }

/* TAB NAVIGATION */
.tab-nav { display:flex; flex-wrap:wrap; background:#000; border-radius:10px; overflow:hidden; }
.tab-nav button {
    flex:1; padding:12px; background:#000; color:white; border:none; cursor:pointer; font-size:16px; transition: background 0.3s;
}
.tab-nav button:hover { background:#04AA6D; }
.tab-nav button.active { background:#04AA6D; }

/* TAB PANELS */
.tab-content {
    max-height:0;
    opacity:0;
    overflow:hidden;
    transition: max-height 0.5s ease, opacity 0.5s ease, margin-top 0.5s ease;
    margin-top:0;
}
.tab-content.active {
    max-height:500px;
    opacity:1;
    margin-top:10px;
}
.tab-content a {
    display:block;
    padding:10px 15px;
    background:#222;
    color:white;
    text-decoration:none;
    margin:2px 0;
    border-radius:5px;
}
.tab-content a:hover { background:#04AA6D; }

/* TABLE STYLING */
h1 { color:#2e7d32; text-align:center; margin:20px 0; }
.filter { text-align:center; margin-bottom:20px; }
select { padding:8px; font-size:15px; border-radius:5px; border:2px solid #4CAF50; background:#f9f9f9; }
table { width:100%; border-collapse:collapse; border-radius:10px; overflow:hidden; box-shadow:0 4px 6px rgba(0,0,0,0.1); }
th, td { padding:12px; text-align:center; border-bottom:1px solid #ddd; }
th { background:#4CAF50; color:white; }
tr:last-child td { background:#e8f5e9; font-weight:bold; color:#2e7d32; }

/* REPORT SECTION SINGLE LINE */
.report-section {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 10px;
    margin-top: 20px;
}
.report-section select {
    flex: 1;
    min-width: 200px;
}
.report-section button {
    flex: none;
    padding: 10px 20px;
    font-size: 16px;
    background:#4CAF50;
    color:white;
    border:none;
    border-radius:8px;
    cursor:pointer;
}
.report-section button:hover { background:#45a049; }

@media(max-width:768px){
    .tab-nav button { font-size:14px; padding:10px; }
    .tab-content a { padding:12px 10px; }
    .report-section { flex-direction: column; align-items: stretch; }
    .report-section button { width:100%; }
}
</style>
</head>
<body>

<div class="main">

<h1>ATGET Dashboard</h1>

<!-- TAB NAVIGATION -->
<div class="tab-nav">
  <button class="tab-link" data-tab="student">Student Management</button>
  <button class="tab-link" data-tab="receipt">Receipt Management</button>
  <a href="../login.html" style="flex:none; margin-left:auto; color:white; padding:12px 16px; text-decoration:none; background:#000; border-radius:6px;">Logout</a>
</div>

<!-- TAB PANELS -->
<div id="student" class="tab-content">
  <a href="addStudent.php">Add Student Details</a>
  <a href="student_details.php">View/Update Student Details</a>
  <a href="update_school_result.php">Update School Results</a>
  <a href="update_non_school_results.php">Update Non-School Results</a>
</div>

<div id="receipt" class="tab-content">
  <a href="receipt_handler.php">Add Receipt</a>
  <a href="view_receipt.php">View Receipt</a>
  <a href="#">Dashboard</a>
</div>
<br><br>
<!-- DASHBOARD FILTER -->
<div class="filter">
  <form method="GET">
    <label for="academic_year">Academic Year:</label>
    <select name="academic_year" id="academic_year" onchange="this.form.submit()">
      <?php foreach($academic_years as $year): ?>
        <option value="<?= $year ?>" <?= $selected_year==$year?'selected':'' ?>><?= $year ?></option>
      <?php endforeach; ?>
    </select>
  </form>
</div>

<!-- DASHBOARD TABLE -->
<table>
  <thead>
    <tr>
      <th>School Name</th>
      <th>Students</th>
      <th>Receipts</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($table_data as $row): ?>
      <tr>
        <td><?= htmlspecialchars($row['school']) ?></td>
        <td><?= htmlspecialchars($row['students']) ?></td>
        <td><?= number_format($row['receipts'],2) ?></td>
      </tr>
    <?php endforeach; ?>
    <tr>
      <td>Total</td>
      <td><?= $total_students ?></td>
      <td><?= number_format($total_receipts,2) ?></td>
    </tr>
  </tbody>
</table>

<!-- REPORT TYPE SINGLE LINE -->
<div class="report-section">
  <label for="ReportType" style="font-weight:bold;">Select Report Type:</label>
  <select name="ReportType" id="ReportType">
    <option value="Complete Receipt Details">Complete Receipt Details</option>
    <option value="Complete Student DB Details">Complete Student DB Details</option>
    <option value="Complete Paid Student List">Complete Paid Student List</option>
    <option value="Pending Fee Student List">Pending Fee Student List</option>
  </select>
  <button type="submit">Submit</button>
</div>

</div>

<script>
// TAB FUNCTIONALITY: Panels hidden by default
const tabs = document.querySelectorAll('.tab-link');
const contents = document.querySelectorAll('.tab-content');

tabs.forEach(tab => {
  tab.addEventListener('click', (e) => {
    const target = document.getElementById(tab.dataset.tab);

    // Toggle panel if already active
    if(target.classList.contains('active')){
      target.classList.remove('active');
      tab.classList.remove('active');
      return;
    }

    // Deactivate all tabs
    tabs.forEach(t => t.classList.remove('active'));
    contents.forEach(c => c.classList.remove('active'));

    // Activate clicked tab and show panel
    tab.classList.add('active');
    setTimeout(() => target.classList.add('active'), 50);

    e.stopPropagation(); // prevent document click from hiding
  });
});

// Hide all panels if click outside tabs/panels
document.addEventListener('click', () => {
  contents.forEach(c => c.classList.remove('active'));
  tabs.forEach(t => t.classList.remove('active'));
});

// Prevent clicks inside panels from closing them
contents.forEach(c => c.addEventListener('click', e => e.stopPropagation()));
</script>

</body>
</html>

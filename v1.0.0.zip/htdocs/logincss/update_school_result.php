<?php
session_start(); // Start session

// --------------------
// Session-based access control
// --------------------
if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    // Not logged in, redirect to login page
    header("Location: ../login.php");
    exit();
}

// Optionally, get username and role
$username = htmlspecialchars($_SESSION['username']);
$role = $_SESSION['role'];

// Then include your config file
require_once 'config.php'; // DB connection

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$errors = [];
$success = '';
$student = null;
$semesters = [];
$standards = [];
$grades = [];
$showForm = false; // Flag to display form only after search

// ---------------------------
// Fetch Semesters
// ---------------------------
$sem_sql = "SELECT Semester_Name FROM ATGET_School_Semisters ORDER BY Semester_Name DESC";
$sem_result = $conn->query($sem_sql);
if ($sem_result && $sem_result->num_rows > 0) {
    while ($row = $sem_result->fetch_assoc()) {
        $semesters[] = $row['Semester_Name'];
    }
}

// ---------------------------
// Fetch Standards
// ---------------------------
$std_sql = "SELECT Standard_list FROM ATGET_School_Standards ORDER BY Standard_list ASC";
$std_result = $conn->query($std_sql);
if ($std_result && $std_result->num_rows > 0) {
    while ($row = $std_result->fetch_assoc()) {
        $standards[] = $row['Standard_list'];
    }
}

// ---------------------------
// Fetch Grades
// ---------------------------
$grade_sql = "SELECT Grading_List FROM ATGET_Grading_List ORDER BY Grading_List ASC";
$grade_result = $conn->query($grade_sql);
if ($grade_result && $grade_result->num_rows > 0) {
    while ($row = $grade_result->fetch_assoc()) {
        $grades[] = $row['Grading_List'];
    }
}

// ---------------------------
// Handle POST
// ---------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Search student
    if (isset($_POST['searchAdmissionNo'])) {
        $admissionNo = trim($_POST['searchAdmissionNo']);
        if (empty($admissionNo)) {
            $errors[] = "Please enter Admission Number.";
        } else {
            $stmt = $conn->prepare("SELECT * FROM ATGET_Students_Details WHERE Admission_No = ?");
            $stmt->bind_param("s", $admissionNo);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                $student = $result->fetch_assoc();
                $showForm = true; // Show form after successful search
            } else {
                $errors[] = "Student with Admission No '$admissionNo' not found.";
            }
        }
    }

    // Insert result
    elseif (isset($_POST['submitResult'])) {
        $admissionNo  = trim($_POST['admissionNo']);
        $class        = trim($_POST['currentClass']);
        $semister     = trim($_POST['semister']);
        $attMarks     = floatval($_POST['attendanceMarks']);
        $assessMarks  = floatval($_POST['assessmentMarks']);
        $theoryMarks  = floatval($_POST['theoryMarks']);
        $labMarks     = floatval($_POST['labMarks']);
        $totalMarks   = $attMarks + $assessMarks + $theoryMarks + $labMarks;
        $grade        = trim($_POST['grade']);

        if ($attMarks <= 0 || $assessMarks <= 0 || $theoryMarks <= 0 || $labMarks <= 0) {
            $errors[] = "Marks must be greater than 0 in all fields.";
        }

        if (!$admissionNo || !$class || !$semister || !$grade) {
            $errors[] = "All fields are required.";
        }

        if (empty($errors)) {
            $stmt = $conn->prepare("INSERT INTO ATGET_Schools_Result_Table 
                (Admission_No, Current_ClassOrStandard, Semister, Marks_Obtained_For_Attendance, Marks_Obtained_In_Assesment, Marks_Obtained_In_Theory_Exam, Marks_Obtained_In_Lab_Exam, Total_Marks_Obtained, Marks_In_Grade)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if ($stmt === false) {
                $errors[] = "Prepare failed: " . $conn->error;
            } else {
                $stmt->bind_param("sssddddds", $admissionNo, $class, $semister, $attMarks, $assessMarks, $theoryMarks, $labMarks, $totalMarks, $grade);
                try {
                    $stmt->execute();
                    $success = "Result updated successfully!";
                } catch (mysqli_sql_exception $e) {
                    if ($e->getCode() == 1062) { // Duplicate entry
                        $errors[] = "Result already updated.";
                    } else {
                        $errors[] = "Database error: " . $e->getMessage();
                    }
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Update Student Result</title>
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: linear-gradient(135deg, #e0f7fa, #f1f8e9);
    margin: 0;
    display: flex;
    justify-content: center;
    padding: 20px;
}
.main-card {
    background: #fff;
    border-radius: 15px;
    padding: 25px;
    box-shadow: 0 0 25px rgba(0,0,0,0.1);
    width: 100%;
    max-width: 700px;
}
.navbar {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
    background-color: #333;
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 20px;
}
.navbar a {
    color: white;
    text-align: center;
    padding: 12px 10px;
    text-decoration: none;
    flex: 1;
    font-size: 15px;
}
.navbar a:hover { background-color: #111; }
.navbar a.active { background-color: #04AA6D; }

h2, h3 { margin: 0; color: #333; }

.error, .success {
    padding: 10px;
    border-radius: 5px;
    margin-bottom: 15px;
}
.error { background-color: #fdd; color: red; }
.success { background-color: #dff0d8; color: #3c763d; }

.search-bar {
    display: flex;
    gap: 10px;
    margin-bottom: 20px;
}
.search-bar input {
    flex: 1;
    padding: 10px;
    font-size: 16px;
    border: 1px solid #ccc;
    border-radius: 8px;
}
.search-bar button {
    background-color: #007bff;
    border: none;
    color: white;
    padding: 10px 16px;
    border-radius: 8px;
    cursor: pointer;
}
.search-bar button:hover { background-color: #0056b3; }

.student-card {
    background: #f9f9f9;
    border-radius: 10px;
    padding: 15px 20px;
    margin-bottom: 25px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    border-left: 5px solid #04AA6D;
}
.student-card p {
    margin: 6px 0;
    font-size: 15px;
}

.form-grid {
    display: flex;
    gap: 20px;
    flex-wrap: wrap;
}
.form-left, .form-right {
    flex: 1;
    min-width: 250px;
}
.form-row {
    display: flex;
    flex-direction: column;
    margin-bottom: 15px;
}
.form-row label {
    font-weight: 600;
    margin-bottom: 5px;
}
.form-row input, .form-row select {
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 16px;
}

button.submit-btn {
    margin-top: 15px;
    background-color: #4CAF50;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 8px;
    cursor: pointer;
    font-size: 16px;
}
button.submit-btn:hover { background-color: #45a049; }

@media (max-width: 600px) {
    .navbar a {
        flex: 1 0 100%;
        border-bottom: 1px solid #444;
    }
    .form-grid {
        flex-direction: column;
    }
}
</style>
</head>
<body>
<div class="main-card">

<!-- Navbar -->
<div class="navbar">
    <a href="atgethome.php">Home</a>
    <a href="logout.php">Logout</a>
</div>

<h2>Update Student Result</h2><br>

<?php if (!empty($errors)): ?>
<div class="error">
    <?php foreach ($errors as $error): ?>
        <p><?= htmlspecialchars($error) ?></p>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php if ($success): ?>
<div class="success"><?= htmlspecialchars($success) ?></div>
<?php endif; ?>

<!-- Always show search bar -->
<form method="POST" action="">
    <div class="search-bar">
        <input type="number" name="searchAdmissionNo" placeholder="Enter Admission No" required />
        <button type="submit">Search</button>
    </div>
</form>

<?php if ($showForm && $student): ?>
<hr>
<div class="student-card">
    <h3>Student Details</h3>
    <p><strong>Name:</strong> <?= htmlspecialchars($student['Student_Name']) ?></p>
    <p><strong>Parent Name:</strong> <?= htmlspecialchars($student['Parent_Name']) ?></p>
    <p><strong>School Name:</strong> <?= htmlspecialchars($student['School_Name']) ?></p>
</div>

<form method="POST" action="">
    <input type="hidden" name="admissionNo" value="<?= htmlspecialchars($student['Admission_No']) ?>" />

    <div class="form-grid">
        <div class="form-left">
            <div class="form-row">
                <label for="currentClass">Current Class / Standard:</label>
                <select id="currentClass" name="currentClass" required>
                    <option value="" disabled selected>-- Select Class --</option>
                    <?php foreach ($standards as $std): ?>
                        <option value="<?= htmlspecialchars($std) ?>"><?= htmlspecialchars($std) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-row">
                <label for="semister">Semester:</label>
                <select id="semister" name="semister" required>
                    <option value="" disabled selected>-- Select Semester --</option>
                    <?php foreach ($semesters as $sem): ?>
                        <option value="<?= htmlspecialchars($sem) ?>"><?= htmlspecialchars($sem) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-row">
                <label>Total Marks Obtained:</label>
                <input type="number" id="totalMarks" name="totalMarks" step="0.01" readonly>
            </div>
        </div>

        <div class="form-right">
            <div class="form-row">
                <label>Marks for Attendance:</label>
                <input type="number" id="attendanceMarks" name="attendanceMarks" step="0.01" min="1" required>
            </div>

            <div class="form-row">
                <label>Marks in Assessment:</label>
                <input type="number" id="assessmentMarks" name="assessmentMarks" step="0.01" min="1" required>
            </div>

            <div class="form-row">
                <label>Marks in Theory Exam:</label>
                <input type="number" id="theoryMarks" name="theoryMarks" step="0.01" min="1" required>
            </div>

            <div class="form-row">
                <label>Marks in Lab Exam:</label>
                <input type="number" id="labMarks" name="labMarks" step="0.01" min="1" required>
            </div>
        </div>
    </div>

    <div class="form-row">
        <label>Grade:</label>
        <select id="grade" name="grade" required>
            <option value="" disabled selected>-- Select Grade --</option>
            <?php foreach ($grades as $g): ?>
                <option value="<?= htmlspecialchars($g) ?>"><?= htmlspecialchars($g) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <button type="submit" name="submitResult" class="submit-btn">Submit Result</button>
</form>

<script>
function calculateTotal() {
    let a = parseFloat(document.getElementById('attendanceMarks').value) || 0;
    let b = parseFloat(document.getElementById('assessmentMarks').value) || 0;
    let c = parseFloat(document.getElementById('theoryMarks').value) || 0;
    let d = parseFloat(document.getElementById('labMarks').value) || 0;
    document.getElementById('totalMarks').value = (a + b + c + d).toFixed(2);
}

document.querySelectorAll('#attendanceMarks, #assessmentMarks, #theoryMarks, #labMarks')
    .forEach(input => input.addEventListener('input', function(e) {
        if (parseFloat(e.target.value) <= 0) {
            e.target.value = '';
            alert('Marks must be greater than 0');
        }
        calculateTotal();
    }));
</script>
<?php endif; ?>
</div>
</body>
</html>

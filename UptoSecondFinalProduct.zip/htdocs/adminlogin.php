<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Include DB config
require_once('config.php');

// Check if form submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');

    if ($user === '' || $pass === '') {
        echo "<script>
                alert('Please enter both username and password.');
                window.location.href = 'adminlogin.php';
              </script>";
        exit;
    }

    // Prepare and execute SQL query
    $sql = $conn->prepare("SELECT * FROM ATGET_Login_Creds WHERE username = ? AND password = ? AND Role = 'Checker'");
    $sql->bind_param("ss", $user, $pass);
    $sql->execute();
    $result = $sql->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();

        // Store session data
        $_SESSION['username'] = $row['username'];
        $_SESSION['role'] = $row['Role'];

        // Redirect to dashboard
        header("Location: logincss/dashboard.php");
        exit();
    } else {
        echo "<script>
                alert('Invalid credentials or not authorized as Checker.');
                window.location.href = 'adminlogin.php';
              </script>";
        exit;
    }

    $sql->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>ATGET Admin Login</title>
    <link rel="stylesheet" href="logincss/style.css">
    <link rel="icon" href="img/ATG Logo.png" type="image/png">
</head>

<body>
    <div class="main">
        <h1>Assure Tech Global Education Trust</h1>
        <h3>Checker Login</h3>

        <form action="adminlogin.php" method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" placeholder="Enter your Username" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" placeholder="Enter your Password" required>

            <div class="wrap">
                <button type="submit">Login</button>
            </div>
        </form>

        <p>Not registered?
            <a href="index.html">Back to Home Page.</a>
        </p>
    </div>
</body>
</html>
